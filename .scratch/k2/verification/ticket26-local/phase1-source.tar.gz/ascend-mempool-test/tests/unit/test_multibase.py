"""Exercise fixed multibase metadata through the external kernel boundary."""

import ctypes
import unittest

import torch

from ascend_mempool.multibase import BaseTable, MultibaseCopy


def cpu_multibase(sb, sr, sv, db, dr, dv, si, di, mask, width, blocks):
    """Independent linear address oracle; no production routing helpers."""
    for source, target, valid in zip(si.tolist(), di.tolist(), mask.tolist()):
        if not valid:
            continue
        src = [
            int(b) + (source - int(r[0])) * width
            for b, r, v in zip(sb, sr, sv)
            if v and int(r[0]) <= source < int(r[1])
        ]
        dst = [
            int(b) + (target - int(r[0])) * width
            for b, r, v in zip(db, dr, dv)
            if v and int(r[0]) <= target < int(r[1])
        ]
        if src and dst:
            ctypes.memmove(dst[0], src[0], width)
