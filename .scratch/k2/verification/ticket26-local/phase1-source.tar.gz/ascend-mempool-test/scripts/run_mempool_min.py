"""One command per NPU container for cold/prefix serving and acceptance."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import signal
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from importlib.metadata import version
from pathlib import Path
from typing import TYPE_CHECKING, Any, Sequence

SCRIPTS = Path(__file__).resolve().parent
REPO = SCRIPTS.parents[1]
sys.path.insert(0, str(REPO / "ascend-mempool-test/src"))

import mempool_logical_cases
import msgspec
import verify_mempool_full
import verify_mempool_min
import verify_mempool_prefix
import verify_mempool_reuse
import verify_mempool_session
import verify_service

SESSION_MODES = (
    "session-acceptance",
    "p-sharing-acceptance",
    "index-sharing-acceptance",
    "prefix-sharing-acceptance",
    "page-first-acceptance",
)
from run_ticket10 import (
    connect,
    model_identity,
    receive_log,
    send_log,
    wait_http,
)
from ticket10_processes import Peer, Processes

if TYPE_CHECKING:
    from sglang.srt.disaggregation.ascend.mempool_router_protocol import (
        CONFIG_ENV,
        RUN_ENV,
        RouterConfig,
    )
    from sglang.srt.hardware_backend.npu.mempool.config import MempoolConfig
    from sglang.srt.hardware_backend.npu.mempool.sharing_plan import (
        HostTopology,
        MempoolNumaConfig,
        PoolSession,
    )
else:
    from ascend_mempool.config import MempoolConfig
    from ascend_mempool.sharing_plan import HostTopology, MempoolNumaConfig, PoolSession
    from ascend_mempool_pd.mempool_router_protocol import (
        CONFIG_ENV,
        RUN_ENV,
        RouterConfig,
    )


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def identity_differences(
    local: dict[str, Any], peer: dict[str, Any], prefix: str = ""
) -> list[dict[str, Any]]:
    """Name exact deployment differences, including files present on one host."""
    differences = []
    for key in sorted(local.keys() | peer.keys()):
        field = f"{prefix}.{key}" if prefix else key
        left, right = local.get(key), peer.get(key)
        if (
            key in local
            and key in peer
            and isinstance(left, dict)
            and isinstance(right, dict)
        ):
            differences.extend(identity_differences(left, right, field))
        elif key not in local or key not in peer or left != right:
            differences.append(
                dict(
                    field=field,
                    local=left,
                    peer=right,
                    local_present=key in local,
                    peer_present=key in peer,
                )
            )
    return differences


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--role", choices=("prefill", "decode"), required=True)
    parser.add_argument(
        "--mode",
        choices=(
            "serve",
            "acceptance",
            "prefix-acceptance",
            "reuse-acceptance",
            "full-acceptance",
            "numa-acceptance",
            "session-acceptance",
            "p-sharing-acceptance",
            "index-sharing-acceptance",
            "prefix-sharing-acceptance",
            "page-first-acceptance",
            "index-cold-diagnosis",
        ),
        required=True,
    )
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument(
        "--log-root", type=Path, default=Path("/home/cryang/log/mempool-min")
    )
    parser.add_argument("--describe", action="store_true")
    parser.add_argument("--replay-responses", type=Path)
    parser.add_argument("--page-allocation", action="store_true")
    parser.add_argument(
        "--component-reports", type=Path, nargs=2, metavar=("COPY", "FETCH")
    )
    parser.add_argument("--resume-after-target", type=Path)
    parser.add_argument("--observation-rounds", type=int, choices=(1, 2), default=1)
    args = parser.parse_args(argv)
    if args.resume_after_target and args.mode != "full-acceptance":
        parser.error("resume-after-target requires full-acceptance")
    if (
        args.mode == "index-cold-diagnosis"
        and args.role == "prefill"
        and args.replay_responses is None
    ):
        parser.error("prefill index-cold-diagnosis requires --replay-responses")
    if args.replay_responses is not None:
        args.replay_responses = args.replay_responses.resolve()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", args.run_id):
        parser.error("run-id must be a simple new directory name")
    if not args.log_root.resolve().is_relative_to(Path("/home/cryang/log").resolve()):
        parser.error("logs must remain under /home/cryang/log/")
    args.config = args.config.resolve()
    return args


def read_component_reports(paths, config, rank):
    """Reuse successful component evidence for the same local rank and geometry."""
    copy, fetch = [json.loads(path.read_text()) for path in paths]
    if copy.get("status") != "passed" or fetch.get("status") != "passed":
        raise ValueError("component reuse requires two passed reports")
    cases = copy.get("cases", [])
    layout = fetch.get("layout", {}).get("layout", {})
    if (
        len(cases) != 3
        or any(
            c.get("status") != "passed" or c.get("page_size") != config.page_size
            for c in cases
        )
        or fetch.get("rank") != rank
        or layout.get("prompt", {}).get("tokens") != config.page_size
        or layout.get("decode", {}).get("tokens") != config.decode_capacity
        or any(
            layout.get(side, {}).get("page_size") != config.page_size
            for side in ("prompt", "decode")
        )
    ):
        raise ValueError("component reports do not match this rank and geometry")
    return copy, fetch


def service_environment(
    config: RouterConfig, args: argparse.Namespace, root: Path, *, target: bool
) -> dict[str, str]:
    env = dict(os.environ)
    for name in (
        CONFIG_ENV,
        RUN_ENV,
        "http_proxy",
        "https_proxy",
        "HTTP_PROXY",
        "HTTPS_PROXY",
        "SGLANG_NPU_MEMPOOL_TEST_CAPACITY",
        "MEMPOOL_RANK_NUMA_MAP",
        "SGLANG_NPU_MEMPOOL_EVIDENCE_DIR",
    ):
        env.pop(name, None)
    env.update(
        PYTHONPATH=str(REPO / "python") + os.pathsep + env.get("PYTHONPATH", ""),
        PYTHONUNBUFFERED="1",
        P_IP=config.prefill_host,
        D_IP=config.decode_host,
        MODEL_PATH=config.model_path,
        LOG_DIR=str(root),
        GRAPH_MODE="graph",
        PREFILL_CAPACITY=str(config.prompt_capacity),
        DECODE_CAPACITY=str(config.decode_capacity),
        CONTEXT_LENGTH=str(config.context_length),
        MAX_TOTAL_TOKENS=str(config.max_total_tokens),
        P_PORT=str(config.prefill_port),
        D_PORT=str(config.decode_port),
        BOOTSTRAP_PORT=str(config.bootstrap_port),
        PAGE_SIZE=str(config.page_size),
        SKIP_SERVER_WARMUP="0",
        MEMPOOL_TIMEOUT=str(config.startup_timeout),
        SGLANG_NPU_MEMPOOL_SHARE="0",
        SGLANG_NPU_MEMPOOL_LOCAL_NUMA_NODE=",".join(map(str, config.numa_nodes)),
        HCCL_SOCKET_IFNAME=config.interface,
        GLOO_SOCKET_IFNAME=config.interface,
    )
    if target and config.verify_prefix:
        env["SGLANG_NPU_MEMPOOL_EVIDENCE_DIR"] = str(root)
    if target:
        env[CONFIG_ENV], env[RUN_ENV] = str(args.config), args.run_id
        if getattr(args, "rank_numa_map", None) is not None:
            env["MEMPOOL_RANK_NUMA_MAP"] = str(args.rank_numa_map)
            env.pop("SGLANG_NPU_MEMPOOL_LOCAL_NUMA_NODE", None)
    return env


def service_ports(config: RouterConfig, role: str, *, target: bool = True) -> set[int]:
    """Check the endpoints this service owns, excluding gaps in NIC reservations."""
    if not target:
        # Reference has no RouterConfig in its environment: every TP rank owns
        # a private P/D session, even when the following target shares pools.
        config = msgspec.structs.replace(
            config,
            prefill_shared=False,
            decode_shared=False,
            prefill_index_shared=False,
            prefix_shared=False,
        )
    host = config.prefill_host if role == "prefill" else config.decode_host
    layout = MempoolConfig(
        prefill_capacity=config.prompt_capacity,
        decode_capacity=config.decode_capacity,
        page_size=config.page_size,
    ).make_mla_layout(
        num_layers=78,
        kv_lora_rank=512,
        qk_rope_head_dim=64,
        prefix_pages=config.prefix_pages,
        indexer_layers=21 if config.prefix_pages else 0,
        index_head_dim=128 if config.prefix_pages else 0,
    )
    nodes = ",".join(map(str, config.numa_nodes))
    plan = MempoolNumaConfig(False, nodes).plan(
        hosts=(HostTopology(host, tuple(range(16)), nodes),),
        tp_size=16,
        role=role,
        instance_id="port-check",
        kv_identity=config.model_path,
        layout=layout,
        prefill_shared=config.prefill_shared,
        decode_shared=config.decode_shared,
        prefill_index_shared=config.prefill_index_shared,
        prefix_shared=config.prefix_shared,
        prefill_groups=config.session_groups,
    )
    sessions = [plan.session(rank) for rank in range(16)]
    ports = {session.nic_base_port + session.participant for session in sessions}
    ports.add(10000)  # run_service.sh --dist-init-addr on both hosts
    ports.add(config.prefill_port if role == "prefill" else config.decode_port)
    if role == "prefill":
        ports.update(session.store_port for session in sessions)
        ports.update((config.main_port, config.control_port))
    return ports


def memory_budget(config: RouterConfig, role: str) -> dict[str, int]:
    layout = MempoolConfig(
        prefill_capacity=config.prompt_capacity,
        decode_capacity=config.decode_capacity,
        page_size=config.page_size,
    ).make_mla_layout(
        num_layers=78,
        kv_lora_rank=512,
        qk_rope_head_dim=64,
        prefix_pages=config.prefix_pages,
        indexer_layers=21 if config.prefix_pages else 0,
        index_head_dim=128 if config.prefix_pages else 0,
    )
    rank = 0 if role == "prefill" else 1
    bm = 16 * layout.contribution_bytes(rank)
    if config.prefill_shared or config.decode_shared or config.prefill_index_shared:
        bm = sum(
            PoolSession(
                layout,
                rank,
                member,
                tuple(range(16)) if config.prefill_index_shared else group,
                0,
                0,
                0,
                0,
                "budget",
                config.prefill_shared,
                config.decode_shared,
                config.prefill_index_shared,
                config.session_groups if config.prefill_index_shared else (),
                config.prefix_shared,
            ).contribution
            for group in config.session_groups
            for member in group
        )
    # Acceptance retains CPU source + <=40 saved pages and bounded readback scratch.
    verification = 0
    if rank == 0 and config.verify_prefix:
        assert (
            layout.prompt_index is not None
            and layout.prefix_main is not None
            and layout.prefix_index is not None
        )
        references = (
            layout.prompt.total_bytes + layout.prompt_index.total_bytes
        ) // layout.prompt.slots
        references += layout.prefix_main.total_bytes + layout.prefix_index.total_bytes
        scratch = 2 * config.prompt_capacity * layout.prompt.row_bytes
        verification = 16 * ((references + scratch + 2**30 - 1) // 2**30) * 2**30
    return dict(
        bm_bytes=bm, verification_bytes=verification, required_bytes=bm + verification
    )


def request_json(
    url: str, *, payload: dict[str, Any] | None = None, timeout: float = 10
) -> dict[str, Any]:
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    request = urllib.request.Request(
        url,
        data=json.dumps(payload).encode() if payload is not None else None,
        headers={"Content-Type": "application/json"},
    )
    with opener.open(request, timeout=timeout) as response:
        return json.load(response)  # type: ignore[no-any-return]


class Runner:
    def __init__(
        self, args: argparse.Namespace, config: RouterConfig, peer: Peer, root: Path
    ) -> None:
        self.args, self.config, self.peer, self.root = args, config, peer, root
        self.session_acceptance = args.mode in SESSION_MODES
        self.full = args.mode == "full-acceptance" or self.session_acceptance
        self.index_acceptance = args.mode == "index-sharing-acceptance"
        self.tokenizer: Any = None
        self.is_p = args.role == "prefill"
        self.host = config.prefill_host if self.is_p else config.decode_host
        self.report: dict[str, Any] = dict(
            status="running",
            role=args.role,
            mode=args.mode,
            coverage="one saved Index K input without prefix reuse; diagnosis only"
            if args.mode == "index-cold-diagnosis"
            else "K1-12 page-first reduced functional acceptance"
            if args.mode == "page-first-acceptance"
            else "K1-08 reduced functional acceptance"
            if config.prefix_shared and self.session_acceptance
            else "K1-07 reduced functional acceptance"
            if config.prefill_index_shared and self.session_acceptance
            else "shared decode functional regression (without ordering probes)"
            if config.decode_shared and self.session_acceptance
            else "K1-05 reduced functional acceptance"
            if config.prefill_shared and self.session_acceptance
            else "K1-02 reduced functional acceptance"
            if self.session_acceptance
            else "ticket04 complete sparse stage0/L0"
            if self.full
            else "ticket03 prefix restore and suffix"
            if config.match_prefix
            else "ticket02 cold prefix save"
            if config.prefix_pages
            else "ticket01 cold requests only",
            user_accepted=False,
            stages=[],
        )
        self.cases: list[dict[str, Any]] = []
        self.reference: list[dict[str, Any]] = []
        self.reference_fork: dict[str, Any] = {}

    def preflight(self) -> None:
        if self.config.interface not in {name for _, name in socket.if_nameindex()}:
            raise ValueError("configured network interface does not exist")
        for node in self.config.numa_nodes:
            if not Path(f"/sys/devices/system/node/node{node}").is_dir():
                raise ValueError(f"configured NUMA node {node} does not exist")
        manifest = model_identity(Path(self.config.model_path), "glm52")
        diff = subprocess.check_output(
            ["git", "diff", "HEAD", "--", "python", "ascend-mempool-test"], cwd=REPO
        )
        (self.root / "code.patch").write_bytes(diff)
        untracked = subprocess.check_output(
            [
                "git",
                "ls-files",
                "--others",
                "--exclude-standard",
                "--",
                "python",
                "ascend-mempool-test",
            ],
            cwd=REPO,
            text=True,
        ).splitlines()
        identity = dict(
            run_id=self.args.run_id,
            mode=self.args.mode,
            # Peer sends JSON, which turns tuple fields such as numa_nodes into
            # lists. Compare the same wire representation on both sides.
            config=json.loads(msgspec.json.encode(self.config)),
            git_sha=subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=REPO, text=True
            ).strip(),
            tracked_diff_sha256=hashlib.sha256(diff).hexdigest(),
            untracked_sha256={
                p: hashlib.sha256((REPO / p).read_bytes()).hexdigest()
                for p in untracked
            },
            model=manifest,
            versions={
                name: version(name)
                for name in ("torch", "torch-npu", "sgl-kernel-npu", "memfabric-hybrid")
            },
        )
        if getattr(self.args, "numa_maps", None) is not None:
            identity["numa_maps"] = self.args.numa_maps
        write_json(self.root / "identity.json", identity)
        self.report["identity"] = identity
        self.peer.send("identity", value=identity)
        peer_identity = self.peer.expect("identity")["value"]
        write_json(self.root / "peer-identity.json", peer_identity)
        differences = identity_differences(identity, peer_identity)
        comparison = dict(
            status="failed" if differences else "passed",
            local_role=self.args.role,
            differences=differences,
        )
        write_json(self.root / "identity-diff.json", comparison)
        self.report["identity_check"] = comparison
        if differences:
            print(
                "IDENTITY_MISMATCH " + json.dumps(comparison, ensure_ascii=False),
                flush=True,
            )
            fields = ", ".join(item["field"] for item in differences)
            raise ValueError(
                f"P/D identity mismatch: {fields}; see {self.root / 'identity-diff.json'}"
            )
        meminfo = Path("/proc/meminfo").read_text()
        (self.root / "meminfo.txt").write_text(meminfo)
        match = re.search(r"^MemAvailable:\s+(\d+)", meminfo, re.M)
        if match is None:
            raise ValueError("/proc/meminfo does not report MemAvailable")
        available = int(match.group(1)) * 1024
        budget = memory_budget(self.config, self.args.role)
        self.report["memory_budget"] = budget
        write_json(self.root / "memory-budget.json", budget)
        required = budget["required_bytes"]
        if available < required:
            raise ValueError(
                f"BM and acceptance buffers need at least {required} host bytes; available={available}"
            )
        with (self.root / "npu-smi.txt").open("w") as report:
            subprocess.run(
                ["npu-smi", "info"],
                stdout=report,
                stderr=subprocess.STDOUT,
                check=True,
            )
        ports = service_ports(self.config, self.args.role)
        if (
            not self.session_acceptance
            and self.args.mode
            not in ("serve", "numa-acceptance", "index-cold-diagnosis")
            and not getattr(self.args, "resume_after_target", None)
        ):
            ports |= service_ports(self.config, self.args.role, target=False)
        if self.is_p:
            ports.update((self.config.bootstrap_port, 24670))
        deadline = time.monotonic() + self.config.operation_timeout
        for port in sorted(ports):
            verify_mempool_session.released_port(
                self.host,
                port,
                timeout=max(0, deadline - time.monotonic()),
                evidence_path=self.root / f"preflight-port-{port}.json",
                check=self.peer.check,
            )
        if self.config.prefix_shared:
            from mempool_numa_runner import topology

            topology(self.root, self.config.interface)
            versions = {}
            for name, path in (
                ("driver", Path("/usr/local/Ascend/driver/version.info")),
                ("cann", Path("/usr/local/Ascend/ascend-toolkit/latest/version.cfg")),
            ):
                versions[name] = dict(
                    path=str(path),
                    status="recorded" if path.exists() else "unavailable",
                    contents=path.read_text() if path.exists() else None,
                )
            write_json(self.root / "platform-versions.json", versions)
        self.peer.barrier("preflight")

    def components(self) -> None:
        previous = getattr(self.args, "component_reports", None)
        if previous:
            records = read_component_reports(
                previous, self.config, 0 if self.is_p else 1
            )
            self.peer.barrier("reuse-components-ready")
            for name, data, source in zip(
                ("page-first-copy", "fetch"), records, previous
            ):
                root = self.root / name
                write_json(root / "report.json", data)
                write_json(root / "reused-from.json", dict(path=str(source.resolve())))
                if self.is_p:
                    receive_log(self.peer, root / "decode-report.json")
                else:
                    send_log(self.peer, root / "report.json")
                self.report["stages"].append(name)
            self.peer.barrier("reuse-components-done")
            return
        if self.args.mode == "page-first-acceptance" or getattr(
            self.args, "page_allocation", False
        ):
            self.page_first_probe()
        root = self.root / "fetch"
        env = service_environment(self.config, self.args, root, target=False)
        command = [
            sys.executable,
            "-u",
            str(SCRIPTS / "verify_fetch.py"),
            "--rank",
            "0" if self.is_p else "1",
            "--head-ip",
            self.config.prefill_host,
            "--device-id",
            "0",
            "--nic-url",
            f"tcp://{self.host}:24770",
            "--store-port",
            "18873",
            "--control-port",
            "18874",
            "--pool-id",
            "0",
            "--layers",
            "78",
            "--s-p",
            str(self.config.page_size if self.config.prefix_shared else 8),
            "--s-d",
            str(self.config.decode_capacity if self.config.prefix_shared else 16),
            "--page-size",
            str(self.config.page_size if self.config.prefix_shared else 1),
            "--heads",
            "1",
            "--kv-dim",
            "576",
            "--graph-rows",
            "16",
            "--active-rows",
            "3",
            "--topk",
            "2048",
            "--block-dims",
            "48",
            "--replay-cycles",
            "1",
            "--warmup",
            "1",
            "--timeout",
            str(self.config.operation_timeout),
            "--report",
            str(root / "report.json"),
        ]
        self.peer.barrier("fetch-start")
        with Processes(root, env) as jobs:
            child = jobs.start("fetch", command)
            jobs.wait(
                "fetch",
                child,
                timeout=self.config.operation_timeout,
                check=self.peer.check,
            )
        if json.loads((root / "report.json").read_text()).get("status") != "passed":
            raise ValueError("NPU P-only/D-only/mixed copy adapter did not pass")
        if self.is_p:
            receive_log(self.peer, root / "decode-report.json")
        else:
            send_log(self.peer, root / "report.json")
        self.peer.barrier("fetch-done")
        self.report["stages"].append("fetch")

    def page_first_probe(self) -> None:
        root = self.root / "page-first-copy"
        env = service_environment(self.config, self.args, root, target=False)
        self.peer.barrier("page-first-copy-start")
        with Processes(root, env) as jobs:
            child = jobs.start(
                "copy",
                [
                    sys.executable,
                    "-u",
                    str(SCRIPTS / "verify_page_first_copy.py"),
                    "--page-size",
                    str(self.config.page_size),
                    "--report",
                    str(root / "report.json"),
                ],
            )
            jobs.wait(
                "copy",
                child,
                timeout=self.config.operation_timeout,
                check=self.peer.check,
            )
        result = json.loads((root / "report.json").read_text())
        if result["status"] != "passed":
            raise ValueError("page-first wide copy/graph check did not pass")
        if self.is_p:
            receive_log(self.peer, root / "decode-report.json")
        else:
            send_log(self.peer, root / "report.json")
        self.peer.barrier("page-first-copy-done")
        self.report["stages"].append("page-first-copy")

    def rejected_inputs(self, base: str) -> dict[str, Any]:
        before = request_json(base + "/status")
        cases: list[dict[str, Any]] = [
            dict(
                input_ids=[7] * (self.config.page_size + 1),
                sampling_params=dict(temperature=0, max_new_tokens=1),
            ),
            dict(
                input_ids=[7] * (self.config.prompt_capacity + self.config.page_size),
                sampling_params=dict(temperature=0, max_new_tokens=1),
            ),
            dict(
                input_ids=[7] * self.config.page_size,
                sampling_params=dict(
                    temperature=0, max_new_tokens=self.config.decode_capacity * 16 + 1
                ),
            ),
            dict(text="unsupported"),
        ]
        for case in cases:
            try:
                request_json(base + "/generate", payload=case)
            except urllib.error.HTTPError as exc:
                if exc.code != 400:
                    raise
            else:
                raise ValueError("unsupported request was admitted")
        after = request_json(base + "/status")
        if any(
            before[k] != after[k]
            for k in ("active", "ledger", "directory", "completed")
        ):
            raise ValueError("rejected requests changed the resource ledger")
        return dict(
            status="passed",
            cases=len(cases),
            ledger_unchanged=True,
            names=["unaligned", "too-long", "generation-limit", "unsupported-text"],
            ledger=after["ledger"],
            directory=after["directory"],
        )

    def timeout_case(
        self, jobs: Processes, server: subprocess.Popen[bytes], root: Path, base: str
    ) -> None:
        """Pause only our P workers, reserve D, and observe a real Main timeout.

        Main stays alive in its own process group. D must retain its native and
        alive allocation; both runners then clean their own child groups. This
        intentionally waits operation_timeout after the successful cold cases.
        """
        self.peer.barrier("timeout-start")
        if self.is_p:
            if server not in jobs.children:
                raise RuntimeError("timeout injection may only pause an owned child")
            before = None
            deadline = time.monotonic() + self.config.operation_timeout + 15
            os.killpg(server.pid, signal.SIGSTOP)
            try:
                case = self.cases[0]
                try:
                    request_json(
                        base + "/generate",
                        payload={k: case[k] for k in ("input_ids", "sampling_params")},
                        timeout=2,
                    )
                except TimeoutError:
                    pass  # Deliberate client disconnect is not cleanup evidence.
                else:
                    raise ValueError("paused P unexpectedly completed a request")
                while True:
                    self.peer.check()
                    after = request_json(base + "/status", timeout=10)
                    if (
                        before is None
                        and after["active"]
                        and "decode" in after["active"]["allocations"]
                    ):
                        before = after
                    if after["fault"]:
                        break
                    if time.monotonic() >= deadline:
                        raise TimeoutError(
                            "Main did not fail-stop after P heartbeat loss"
                        )
                    time.sleep(0.5)
                if before is None:
                    raise ValueError(
                        "timeout happened before D actually reserved native storage"
                    )
                try:
                    request_json(
                        base + "/generate",
                        payload={k: case[k] for k in ("input_ids", "sampling_params")},
                    )
                except urllib.error.HTTPError as exc:
                    if exc.code != 503:
                        raise
                else:
                    raise ValueError("fail-stop admitted another request")
                write_json(
                    root / "timeout-snapshots.json", dict(before=before, after=after)
                )
                self.peer.send("fault-result", rid=after["active"]["rid"])
                receive_log(self.peer, root / "decode-fault.log")
                evidence = verify_mempool_min.check_timeout(
                    before,
                    after,
                    (root / "decode-fault.log").read_text(errors="replace"),
                )
                self.peer.send("fault-verified", evidence=evidence)
            finally:
                # SIGTERM alone cannot reap a stopped process group.
                try:
                    os.killpg(server.pid, signal.SIGCONT)
                except ProcessLookupError:
                    pass
        else:
            # Native workers are expected to exit on Main's error broadcast.
            # Keep the paired runner alive to collect logs and perform cleanup.
            self.peer.expect("fault-result")
            send_log(self.peer, root / "decode.log")
            evidence = self.peer.expect("fault-verified")["evidence"]
            if self.full:
                code = server.wait(timeout=self.config.operation_timeout)
                if code == 0:
                    raise ValueError("fail-stop worker exited successfully")
                write_json(root / "worker-exit.json", dict(returncode=code))
        write_json(root / "timeout.json", evidence)
        self.report["timeout_fail_stop"] = evidence

    def final_timeout_evidence(self, root: Path) -> None:
        """Check the complete D log after both owned process groups have exited."""
        if self.is_p:
            receive_log(self.peer, root / "decode-fault-final.log")
            snapshots = json.loads((root / "timeout-snapshots.json").read_text())
            evidence = verify_mempool_min.check_timeout(
                snapshots["before"],
                snapshots["after"],
                (root / "decode-fault-final.log").read_text(errors="replace"),
            )
            evidence["process_cleanup_verified"] = True
            if self.full:
                code = self.peer.expect("fault-exit")["returncode"]
                if type(code) is not int or code == 0:
                    raise ValueError("missing fail-stop worker failure exit")
                evidence["worker_exit"] = code
            self.peer.send("fault-final-verified", evidence=evidence)
        else:
            send_log(self.peer, root / "decode.log")
            if self.full:
                self.peer.send(
                    "fault-exit", **json.loads((root / "worker-exit.json").read_text())
                )
            evidence = self.peer.expect("fault-final-verified")["evidence"]
        write_json(root / "timeout.json", evidence)
        self.report["timeout_fail_stop"] = evidence
        self.report["paired_process_cleanup"] = "passed; both owned groups stopped"

    def observation_fork_report(
        self, case: dict[str, Any], result: dict[str, Any], *, target: bool
    ) -> dict[str, Any]:
        verify_mempool_min.check_response(case, result)
        report = dict(
            case=case,
            result=result,
            answer=mempool_logical_cases.answer(case, result),
            acceptance="full output token IDs equal to this run's formal reference",
            answer_policy="diagnostic only for this fork; K1-07 known model answer issue",
            status="reference-recorded",
        )
        if target:
            verify_mempool_min.check_response(case, self.reference_fork)
            ids = mempool_logical_cases.id_difference(self.reference_fork, result)
            report.update(
                status="passed" if ids["equal"] else "failed",
                ids=ids,
                reference_answer=mempool_logical_cases.answer(
                    case, self.reference_fork
                ),
            )
        else:
            self.reference_fork = result
        return report

    def stage(
        self, *, target: bool, fault_only: bool = False, restart: bool = False
    ) -> None:
        name = (
            "restart"
            if restart
            else "timeout"
            if fault_only
            else "target"
            if target
            else "reference"
        )
        inject_fault = (
            target
            and (
                not self.full or fault_only or (self.session_acceptance and not restart)
            )
            and self.args.mode != "index-cold-diagnosis"
        )
        root = self.root / name
        env = service_environment(self.config, self.args, root, target=target)
        self.peer.barrier(name + "-start")
        with Processes(root, env) as jobs:
            router = None
            if self.is_p and target:
                router = jobs.start(
                    "router",
                    [
                        sys.executable,
                        "-u",
                        "-m",
                        "sglang.srt.disaggregation.ascend.mempool_router",
                        "--config",
                        str(self.args.config),
                        "--run-id",
                        self.args.run_id,
                    ],
                )
            server = jobs.start(
                "launcher",
                ["bash", str(SCRIPTS / "run_service.sh"), self.args.role, "formal"],
            )

            def watch() -> None:
                jobs.alive("NPU service", server)
                if router is not None:
                    jobs.alive("Router", router)
                self.peer.check()

            wait_http(
                self.config.backend(self.args.role) + "/ready",
                self.config.startup_timeout,
                watch,
            )
            self.peer.barrier(name + "-backends-up")
            base = f"http://{self.config.prefill_host}:{self.config.main_port}"
            if self.is_p:
                if not target:
                    router = jobs.start(
                        "reference-router",
                        [
                            sys.executable,
                            "-m",
                            "sglang_router.launch_router",
                            "--pd-disaggregation",
                            "--policy",
                            "round_robin",
                            "--prefill",
                            self.config.backend("prefill"),
                            str(self.config.bootstrap_port),
                            "--decode",
                            self.config.backend("decode"),
                            "--host",
                            self.config.prefill_host,
                            "--port",
                            str(self.config.main_port),
                            "--mini-lb",
                            "--request-timeout-secs",
                            str(int(self.config.operation_timeout)),
                        ],
                    )
                wait_http(
                    base + ("/ready" if target else "/health"),
                    self.config.startup_timeout,
                    watch,
                )
            self.peer.barrier(name + "-ready")
            if (
                target
                and not fault_only
                and self.is_p
                and getattr(self.args, "numa_maps", None)
            ):
                from mempool_numa_runner import archive_registration

                archive_registration(self, root, request_json(base + "/status"))
            if (
                self.session_acceptance
                or (self.full and target and self.config.prefix_shared)
            ) and self.is_p:
                registrations = request_json(base + "/status")["registrations"]
                write_json(root / "registrations.json", registrations)
                verify_mempool_session.check_registration(
                    registrations, config=self.config
                )
                write_json(
                    root / "capacity-replay.json",
                    verify_mempool_session.capacity_check(
                        self.config, self.args.run_id, registrations
                    ),
                )
            if self.args.mode == "serve":
                print(
                    f"SERVING {self.args.role}; unified entry: {base}/generate",
                    flush=True,
                )
                while True:
                    watch()
                    if self.is_p:
                        status = request_json(base + "/status")
                        if status["fault"]:
                            raise RuntimeError(status["fault"])
                    time.sleep(1)
            if self.args.mode == "index-cold-diagnosis":
                from mempool_index_diagnosis import run_stage

                run_stage(self, root, base, watch)
            elif not fault_only:
                if self.is_p:
                    snapshots, results, answers = [], [], []
                    if target and not self.full:
                        write_json(
                            root / "input-rejections.json", self.rejected_inputs(base)
                        )
                    for index, case in enumerate(self.cases):
                        watch()
                        requested_ns = (
                            time.monotonic_ns()
                            if getattr(self.args, "observation_rounds", 1) == 2
                            else 0
                        )
                        result = request_json(
                            base + "/generate",
                            payload={
                                k: case[k] for k in ("input_ids", "sampling_params")
                            },
                            timeout=self.config.operation_timeout,
                        )
                        if getattr(self.args, "observation_rounds", 1) == 2:
                            result["observation_request_wall_ns"] = (
                                time.monotonic_ns() - requested_ns
                            )
                        if (
                            self.full
                            and self.tokenizer is not None
                            and isinstance(result.get("output_ids"), list)
                        ):
                            result["server_text"] = result.get("text")
                            result["text"] = self.tokenizer.decode(
                                result.get("output_ids", []), skip_special_tokens=True
                            )
                        # Preserve failing outputs too, before any acceptance assertion.
                        results.append(result)
                        if target:
                            snapshots.append(request_json(base + "/status", timeout=30))
                        write_json(
                            root / "responses.json",
                            dict(cases=self.cases, results=results),
                        )
                        write_json(root / "snapshots.json", snapshots)
                        if self.full:
                            answers.append(
                                mempool_logical_cases.compare_answers(
                                    case, self.reference[index], result
                                )
                                if target and not self.session_acceptance
                                else dict(
                                    mempool_logical_cases.answer(case, result),
                                    case=case["name"],
                                    policy=mempool_logical_cases.POLICY,
                                )
                            )
                            write_json(root / "answers.json", answers)
                        verify_mempool_min.check_response(case, result)
                        if (
                            target
                            and (
                                not self.full
                                or getattr(self.args, "page_allocation", False)
                            )
                            and result["output_ids"]
                            != self.reference[index]["output_ids"]
                        ):
                            raise ValueError(
                                f"{case['name']}: full output IDs differ from formal reference"
                            )
                    if not target and self.full:
                        write_json(
                            root / "stability.json",
                            mempool_logical_cases.check_stability(self.cases, results),
                        )
                    if target and self.index_acceptance:
                        accuracy = mempool_logical_cases.check_index_accuracy(
                            self.cases, results, snapshots
                        )
                        write_json(root / "index-accuracy.json", accuracy)
                        if accuracy["status"] != "passed" or any(
                            a["status"] != "passed" for a in answers
                        ):
                            raise ValueError(
                                "Index K logical accuracy failed; preserve answers and discuss diagnosis without BM readback"
                            )
                    if target and self.full:
                        write_json(
                            root / "input-rejections.json", self.rejected_inputs(base)
                        )
                    deadline = time.monotonic() + 60
                    while True:
                        watch()
                        self.peer.send("stage-control", action="snapshot")
                        receive_log(self.peer, root / "decode.log")
                        try:
                            evidence = (
                                verify_mempool_min.check_target(
                                    root / "prefill.log",
                                    root / "decode.log",
                                    snapshots,
                                    self.cases,
                                    page_size=self.config.page_size,
                                    prompt_capacity=self.config.prompt_capacity,
                                    decode_capacity=self.config.decode_capacity,
                                    prefix=bool(self.config.prefix_pages),
                                )
                                if target
                                else verify_service.check_logs(
                                    [root / "prefill.log"],
                                    [root / "decode.log"],
                                    len(self.cases),
                                    layers=78,
                                    indexer_layer_ids=verify_mempool_min.PRODUCERS,
                                    graph=True,
                                    expected_zero_decode=(
                                        0 if self.config.prefix_pages else None
                                    ),
                                )
                            )
                            if target and self.config.prefix_pages:
                                check = (
                                    verify_mempool_reuse.check_reuse
                                    if self.config.match_prefix
                                    else verify_mempool_prefix.check_prefix
                                )
                                evidence["prefix"] = (
                                    verify_mempool_reuse.check_reuse(
                                        root / "prefill.log",
                                        snapshots,
                                        self.cases,
                                        full=True,
                                    )
                                    if self.full
                                    else check(
                                        root / "prefill.log", snapshots, self.cases
                                    )
                                )
                                evidence["coverage"] = self.report["coverage"]
                            break
                        except (ValueError, RuntimeError, KeyError) as exc:
                            if time.monotonic() >= deadline:
                                write_json(
                                    root / "evidence.json",
                                    dict(
                                        status="failed",
                                        error=f"{type(exc).__name__}: {exc}",
                                    ),
                                )
                                raise
                            time.sleep(1)
                    write_json(root / "evidence.json", evidence)
                    if not target:
                        self.reference = results
                    if getattr(self.args, "observation_rounds", 1) == 2:
                        # Keep ticket09's six frozen receipts; add one sibling
                        # on the same live service, without another model start.
                        fork_case = mempool_logical_cases.make_index_cases(
                            self.tokenizer, self.cases
                        )[1]
                        fork_case["name"] = "observation-fork-update"
                        started = time.monotonic_ns()
                        fork_result = request_json(
                            base + "/generate",
                            payload={
                                k: fork_case[k]
                                for k in ("input_ids", "sampling_params")
                            },
                            timeout=self.config.operation_timeout,
                        )
                        fork_result["observation_request_wall_ns"] = (
                            time.monotonic_ns() - started
                        )
                        verify_mempool_min.check_response(fork_case, fork_result)
                        fork_result["text"] = self.tokenizer.decode(
                            fork_result["output_ids"], skip_special_tokens=True
                        )
                        fork_report = self.observation_fork_report(
                            fork_case, fork_result, target=target
                        )
                        write_json(
                            root / "observation-fork.json",
                            fork_report,
                        )
                        if fork_report["status"] == "failed":
                            raise ValueError(
                                "observation fork output IDs differ from formal reference"
                            )
                    self.peer.send("stage-control", action="done")
                else:
                    while True:
                        message = self.peer.expect("stage-control", check=watch)
                        if message == dict(action="done"):
                            break
                        if message != dict(action="snapshot"):
                            raise ValueError("unknown runner action")
                        send_log(self.peer, root / "decode.log")
            if inject_fault:
                # Freeze the successful normal logs before the intentional fault.
                if not fault_only:
                    for role in ("prefill", "decode") if self.is_p else ("decode",):
                        (root / f"{role}-normal.log").write_bytes(
                            (root / f"{role}.log").read_bytes()
                        )
                self.timeout_case(jobs, server, root, base)
            if target and self.config.observe and not inject_fault:
                if self.is_p:
                    request_json(base + "/observation/flush", payload={})
                    deadline = time.monotonic() + self.config.operation_timeout
                    while request_json(base + "/status").get("observation_flushed") != [
                        "decode",
                        "prefill",
                    ]:
                        watch()
                        if time.monotonic() >= deadline:
                            raise TimeoutError(
                                "observation export did not finish on both sides"
                            )
                        time.sleep(0.2)
                self.peer.barrier(name + "-observation-exported")
        self.peer.barrier(name + "-stopped")
        if target and self.config.observe and not inject_fault:
            from analyze_k2_observation import summarize_directory

            observation_root = root / "observe"
            analysis = summarize_directory(observation_root)
            write_json(root / "observation.json", analysis)
            write_json(
                root / "observation-checks.json",
                {key: analysis[key] for key in ("status", "missing", "coverage")},
            )
            if self.is_p:
                receive_log(self.peer, root / "decode-observation-checks.json")
            else:
                send_log(self.peer, root / "observation-checks.json")
            self.peer.barrier(name + "-observation-collected")
        if inject_fault:
            self.final_timeout_evidence(root)
        if (
            self.session_acceptance
            or self.args.mode == "index-cold-diagnosis"
            or (self.full and self.config.prefix_shared)
        ):
            ports = service_ports(self.config, self.args.role, target=target)
            deadline = time.monotonic() + self.config.operation_timeout
            for port in sorted(ports):
                verify_mempool_session.released_port(
                    self.host,
                    port,
                    timeout=max(0, deadline - time.monotonic()),
                    evidence_path=root / f"port-release-{port}.json",
                    check=self.peer.check,
                )
            self.peer.barrier(name + "-ports-released")
            write_json(
                root / "ports-released.json",
                dict(status="passed", paired=True, ports=sorted(ports)),
            )
        write_json(root / "process-cleanup.json", dict(status="passed", paired=True))
        self.report["stages"].append(name)
        write_json(self.root / "summary.json", self.report)

    def capacity_stage(self) -> None:
        """Reject a real TP registration with one deliberately limited rank."""
        root = self.root / "capacity"
        env = service_environment(self.config, self.args, root, target=True)
        env["SGLANG_NPU_MEMPOOL_TEST_CAPACITY"] = "1"
        base = f"http://{self.config.prefill_host}:{self.config.main_port}"
        self.peer.barrier("capacity-start")
        before, after, http_status, worker_exit = {}, {}, 0, 0
        with Processes(root, env) as jobs:
            router = None
            if self.is_p:
                router = jobs.start(
                    "router",
                    [
                        sys.executable,
                        "-u",
                        "-m",
                        "sglang.srt.disaggregation.ascend.mempool_router",
                        "--config",
                        str(self.args.config),
                        "--run-id",
                        self.args.run_id,
                    ],
                )
                wait_http(
                    base + "/status", self.config.startup_timeout, self.peer.check
                )
                before = request_json(base + "/status")
            self.peer.barrier("capacity-main-up")
            server = jobs.start(
                "launcher",
                ["bash", str(SCRIPTS / "run_service.sh"), self.args.role, "formal"],
            )
            if self.is_p:
                deadline = time.monotonic() + self.config.startup_timeout
                while True:
                    self.peer.check()
                    if router is not None:
                        jobs.alive("Router", router)
                    server_exited = server.poll() is not None
                    after = request_json(base + "/status")
                    if after["fault"]:
                        break
                    if server_exited:
                        jobs.alive(f"NPU service (see {root / 'launcher.log'})", server)
                    if time.monotonic() >= deadline:
                        raise TimeoutError(
                            "capacity-limited registration did not fail-stop"
                        )
                    time.sleep(0.5)
                case = self.cases[0]
                try:
                    request_json(
                        base + "/generate",
                        payload={k: case[k] for k in ("input_ids", "sampling_params")},
                    )
                except urllib.error.HTTPError as exc:
                    http_status = exc.code
                else:
                    raise ValueError("capacity-limited deployment admitted a request")
                after = request_json(base + "/status")
                write_json(root / "snapshots.json", dict(before=before, after=after))
                self.peer.send("capacity-fault")
                worker_exit = self.peer.expect("capacity-exit")["returncode"]
            else:

                def watch_registration() -> None:
                    if server.poll() is not None:
                        # A capacity rejection intentionally exits the worker.
                        # Other startup exits must fail the paired run promptly.
                        if not request_json(base + "/status")["fault"]:
                            jobs.alive(
                                f"NPU service (see {root / 'launcher.log'})", server
                            )

                self.peer.expect("capacity-fault", check=watch_registration)
                worker_exit = server.wait(timeout=self.config.operation_timeout)
                self.peer.send("capacity-exit", returncode=worker_exit)
        self.peer.barrier("capacity-stopped")
        if self.is_p:
            receive_log(self.peer, root / "decode.log")
            evidence = verify_mempool_full.check_capacity_rejection(
                before,
                after,
                (root / "decode.log").read_text(errors="replace"),
                run_id=self.args.run_id,
                http_status=http_status,
                worker_exit=worker_exit,
                required_pages=(
                    self.config.prompt_capacity + self.config.decode_capacity
                )
                // self.config.page_size,
            )
            self.peer.send("capacity-verified", evidence=evidence)
        else:
            send_log(self.peer, root / "decode.log")
            evidence = self.peer.expect("capacity-verified")["evidence"]
        if self.config.prefix_shared:
            deadline = time.monotonic() + self.config.operation_timeout
            for port in sorted(service_ports(self.config, self.args.role)):
                verify_mempool_session.released_port(
                    self.host,
                    port,
                    timeout=max(0, deadline - time.monotonic()),
                    evidence_path=root / f"port-release-{port}.json",
                    check=self.peer.check,
                )
            self.peer.barrier("capacity-ports-released")
        write_json(root / "evidence.json", evidence)
        write_json(root / "process-cleanup.json", dict(status="passed", paired=True))
        self.report["stages"].append("capacity")

    def prepare_full_cases(self) -> None:
        if self.is_p:
            from transformers import AutoTokenizer

            self.tokenizer = AutoTokenizer.from_pretrained(
                self.config.model_path, trust_remote_code=True
            )
            self.cases = mempool_logical_cases.make_cases(
                self.tokenizer, self.config.page_size
            )
            self.cases += mempool_logical_cases.make_controls(
                self.tokenizer,
                self.config.page_size,
                self.config.decode_capacity,
                page_allocation=getattr(self.args, "page_allocation", False),
            )
            if self.index_acceptance:
                self.cases += mempool_logical_cases.make_index_cases(
                    self.tokenizer, self.cases
                )
            write_json(self.root / "cases.json", self.cases)
            send_log(self.peer, self.root / "cases.json")
        else:
            receive_log(self.peer, self.root / "cases.json")
            self.cases = json.loads((self.root / "cases.json").read_text())
        self.peer.barrier("fixtures-ready")

    def run_session(self) -> None:
        self.prepare_full_cases()
        self.components()
        for phase in verify_mempool_session.SERVICE_STAGES:
            self.stage(target=True, restart=phase == "restart")
        if self.is_p:
            acceptance = verify_mempool_session.summarize(
                self.root,
                config=self.config
                if self.config.prefill_shared
                or self.config.decode_shared
                or self.config.prefill_index_shared
                else None,
                mode=self.args.mode,
            )
            if self.args.mode == "page-first-acceptance":
                from verify_mempool_shared import check_page_first_registration

                acceptance["page_first"] = {
                    phase: check_page_first_registration(
                        json.loads(
                            (self.root / phase / "registrations.json").read_text()
                        ),
                        self.config,
                    )
                    for phase in verify_mempool_session.SERVICE_STAGES
                }
            self.peer.send("session-result", acceptance=acceptance)
        else:
            acceptance = self.peer.expect("session-result")["acceptance"]
        write_json(
            self.root
            / (
                "page-first-acceptance.json"
                if self.args.mode == "page-first-acceptance"
                else "prefix-sharing-acceptance.json"
                if self.config.prefix_shared
                else "index-sharing-acceptance.json"
                if self.index_acceptance
                else "session-acceptance.json"
                if self.config.decode_shared
                else "p-sharing-acceptance.json"
                if self.config.prefill_shared
                or self.config.decode_shared
                or self.config.prefill_index_shared
                else "session-acceptance.json"
            ),
            acceptance,
        )
        self.report.update(status="passed", acceptance=acceptance, user_accepted=False)

    def run_full(self) -> None:
        previous = getattr(self.args, "resume_after_target", None)
        if previous:
            from mempool_service_resume import reuse_completed_stages

            self.cases = reuse_completed_stages(
                previous, self.root, self.report["identity"], self.args.role
            )
            self.peer.barrier("reuse-services-ready")
            self.report["stages"].extend(["reference", "target"])
            self.report["reused_from"] = str(previous.resolve())
            write_json(self.root / "summary.json", self.report)
            print(
                f"REUSED components/reference/target from {previous}; next=capacity",
                flush=True,
            )
        else:
            self.prepare_full_cases()
            self.components()
            self.stage(target=False)
            if getattr(self.args, "observation_rounds", 1) == 2:
                self.stage(target=True, restart=True)
            self.stage(target=True)
        self.capacity_stage()
        self.stage(target=True, fault_only=True)
        if self.is_p:
            acceptance = verify_mempool_full.summarize(
                self.root,
                page_size=self.config.page_size,
                decode_capacity=self.config.decode_capacity,
            )
            if self.config.prefix_shared:
                import verify_mempool_shared

                target = self.root / "target"
                registrations = json.loads((target / "registrations.json").read_text())
                acceptance["k1"] = dict(
                    shared=verify_mempool_shared.check_stage(target, self.config),
                    layout=verify_mempool_shared.check_page_first_registration(
                        registrations, self.config
                    ),
                    omitted_checks=[
                        "startup cross-writer probes",
                        "per-step decode sentinels and delayed-writer Graph test",
                        "pool-copy artificial delay and timing/poll evidence",
                    ],
                )
                fetch = json.loads(
                    (self.root / "fetch" / "decode-report.json").read_text()
                )
                boundaries = [
                    c for c in fetch["checks"] if c.get("case") == "page_boundaries"
                ]
                expected_positions = sorted(
                    {
                        0,
                        self.config.decode_capacity - 2,
                        self.config.decode_capacity - 1,
                    }
                    | {
                        k + delta
                        for k in range(
                            self.config.page_size,
                            self.config.decode_capacity,
                            self.config.page_size,
                        )
                        for delta in (-1, 0, 1)
                        if 0 <= k + delta < self.config.decode_capacity
                    }
                )
                if (
                    len(boundaries) != 1
                    or boundaries[0].get("decode_positions") != expected_positions
                    or boundaries[0].get("page_size") != self.config.page_size
                    or len(boundaries[0].get("layers", [])) != 78
                ):
                    raise ValueError(
                        "missing actual-geometry cross-page gather evidence"
                    )
                acceptance["k1"]["boundaries"] = boundaries[0]
                acceptance["coverage"] = "K1 functional regression after probe cleanup"
            self.peer.send("full-result", acceptance=acceptance)
        else:
            acceptance = self.peer.expect("full-result")["acceptance"]
        write_json(self.root / "v1-v10.json", acceptance)
        self.report["acceptance"] = acceptance
        if acceptance["status"] != "passed":
            raise ValueError(
                "full acceptance failed; see v1-v10.json and per-stage evidence"
            )
        self.report.update(
            status="passed",
            output_policy=mempool_logical_cases.POLICY,
            hardware_execution="completed by user runner",
            user_accepted=False,
        )

    def run(self) -> None:
        self.preflight()
        if self.args.mode == "index-cold-diagnosis":
            from mempool_index_diagnosis import run

            run(self)
            return
        if self.args.mode == "numa-acceptance":
            from mempool_numa_runner import run

            run(self)
            return
        if self.session_acceptance:
            self.run_session()
            return
        if self.full:
            self.run_full()
            return
        if self.args.mode != "serve":
            self.components()
            if self.is_p:
                fixtures = (
                    verify_mempool_reuse
                    if self.config.match_prefix
                    else verify_mempool_prefix
                    if self.config.prefix_pages
                    else verify_mempool_min
                )
                self.cases = fixtures.make_cases(
                    self.config.model_path, self.config.page_size
                )
                write_json(self.root / "cases.json", self.cases)
            self.peer.barrier("fixtures-ready")
            self.stage(target=False)
        self.stage(target=True)
        self.report.update(
            status="passed",
            accuracy="full output IDs equal to same-length formal reference",
            hardware_execution="completed by user runner",
            prefix="content/lifecycle checked"
            if self.config.prefix_pages
            else "not covered",
        )


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    config = RouterConfig.read(str(args.config))
    root = args.log_root / args.run_id / args.role
    requested = msgspec.to_builtins(config)
    if args.mode in (
        "prefix-acceptance",
        "reuse-acceptance",
        "full-acceptance",
        "numa-acceptance",
        "session-acceptance",
        "p-sharing-acceptance",
        "index-sharing-acceptance",
        "prefix-sharing-acceptance",
        "page-first-acceptance",
        "index-cold-diagnosis",
    ):
        config = msgspec.structs.replace(
            config,
            prefix_pages=5120 // config.page_size,
            verify_prefix=True,
            match_prefix=args.mode
            in (
                "reuse-acceptance",
                "full-acceptance",
                "numa-acceptance",
                "session-acceptance",
                "p-sharing-acceptance",
                "index-sharing-acceptance",
                "prefix-sharing-acceptance",
                "page-first-acceptance",
            ),
        )
    elif args.mode == "acceptance" and config.prefix_pages:
        raise ValueError(
            "ticket01 acceptance requires prefix_pages=0; use prefix-acceptance"
        )
    if args.mode == "p-sharing-acceptance":
        config = msgspec.structs.replace(config, prefill_shared=True)
    if args.mode in (
        "index-sharing-acceptance",
        "index-cold-diagnosis",
        "prefix-sharing-acceptance",
        "page-first-acceptance",
    ):
        config = msgspec.structs.replace(
            config,
            prefill_shared=True,
            decode_shared=True,
            prefill_index_shared=True,
            prefix_shared=args.mode
            in ("prefix-sharing-acceptance", "page-first-acceptance")
            or config.prefix_shared,
        )
    args.config = root / "effective-config.json"
    if args.describe:
        print(
            json.dumps(
                dict(
                    role=args.role,
                    mode=args.mode,
                    config=msgspec.to_builtins(config),
                    logs=str(root),
                    memory_budget=memory_budget(config, args.role),
                    storage_order="page_first",
                    copy_probe="small + 11.78 GB device arena, last slot and graph replay; before model startup"
                    if args.mode == "page-first-acceptance"
                    else None,
                    output_policy="strict saved fixture answer; old/cold output IDs diagnostic"
                    if args.mode == "index-cold-diagnosis"
                    else mempool_logical_cases.POLICY
                    if args.mode
                    in ("full-acceptance", "numa-acceptance", *SESSION_MODES)
                    else "strict full output IDs",
                    acceptance_controls=(
                        "one skipped allocator page; fill submitted after native_freed"
                        if config.match_prefix and config.verify_prefix
                        else "none"
                    ),
                    service_rounds=1
                    if args.mode == "index-cold-diagnosis"
                    else len(verify_mempool_session.SERVICE_STAGES)
                    if args.mode in SESSION_MODES
                    else None,
                    stages=[
                        "paired preflight; one P/D/mixed fetch smoke (48, one replay)",
                        "round 1: ABCE + load/EOS, registration and accounting, then fail-stop",
                        "round 2: same-port restart, ABCE + load/EOS, default process cleanup",
                        "independent answers; capacity rejection CPU replay; paired port cleanup",
                    ]
                    if args.mode in SESSION_MODES
                    else [
                        "paired preflight; same sharing layout, prefix matching disabled",
                        "one saved index-update request; original input IDs and sampling",
                        "strict answer and old/cold comparison; paired process cleanup",
                        "diagnosis only; no automatic BM readback or ticket acceptance",
                    ]
                    if args.mode == "index-cold-diagnosis"
                    else [
                        "local startup rejection codes: offline node / duplicate rank / missing rank",
                        "default and swapped explicit maps: A/B/C/E and V1-V10",
                        "applied registration reports, per-region page samples and per-NUMA resident bytes",
                        "topology/version snapshots and paired cleanup; no performance instrumentation",
                    ]
                    if args.mode == "numa-acceptance"
                    else [
                        "paired preflight",
                        "P-only/D-only/mixed NPU fetch",
                        "independent logical ABCE + load/EOS reference",
                        "Main/SR logical ABCE + load/EOS target and cleanup",
                        "isolated registration-capacity rejection",
                        "isolated timeout/fail-stop and paired cleanup",
                        "V1-V10 evidence and independent answers",
                    ]
                    if args.mode == "full-acceptance"
                    else [
                        "paired preflight",
                        "P-only/D-only/mixed NPU fetch",
                        "formal reference A/B/C"
                        if config.match_prefix
                        else "formal reference A/B/C/E"
                        if config.prefix_pages
                        else "formal reference 4096+128",
                        "Main/SR target and cleanup",
                        "timeout/fail-stop and paired cleanup",
                    ]
                    if args.mode != "serve"
                    else ["paired preflight", "Main and P/D persistent services"],
                    service_command=[
                        "bash",
                        str(SCRIPTS / "run_service.sh"),
                        args.role,
                        "formal",
                    ],
                    target_environment={
                        k: v
                        for k, v in service_environment(
                            config, args, root, target=True
                        ).items()
                        if k
                        in (
                            CONFIG_ENV,
                            RUN_ENV,
                            "CONTEXT_LENGTH",
                            "PREFILL_CAPACITY",
                            "DECODE_CAPACITY",
                            "PAGE_SIZE",
                            "MAX_TOTAL_TOKENS",
                            "SKIP_SERVER_WARMUP",
                        )
                    },
                ),
                indent=2,
            )
        )
        return 0
    os.chdir(REPO)
    root.mkdir(parents=True, exist_ok=False)
    write_json(root / "requested-config.json", requested)
    write_json(args.config, msgspec.to_builtins(config))
    report: dict[str, Any] = dict(status="failed", mode=args.mode, role=args.role)

    def stop(signum: int, frame: Any) -> None:
        raise KeyboardInterrupt(f"runner received signal {signum}")

    for signum in (signal.SIGINT, signal.SIGTERM):
        signal.signal(signum, stop)
    peer_args = argparse.Namespace(
        role=args.role,
        prefill_host=config.prefill_host,
        decode_host=config.decode_host,
        control_port=config.runner_port,
        timeout=config.startup_timeout,
    )
    try:
        with Peer(connect(peer_args), config.startup_timeout) as peer:
            runner = Runner(args, config, peer, root)
            report = runner.report
            try:
                runner.run()
            except BaseException as exc:
                report.update(status="failed", error=f"{type(exc).__name__}: {exc}")
                try:
                    peer.send("error", message=str(exc))
                except OSError:
                    pass
                raise
    except BaseException as exc:
        report.update(status="failed", error=f"{type(exc).__name__}: {exc}")
        print(report["error"], file=sys.stderr)
        return 1
    finally:
        if args.mode == "full-acceptance" and args.role == "prefill":
            if "acceptance" not in report:
                report["acceptance"] = verify_mempool_full.summarize(
                    root,
                    page_size=config.page_size,
                    decode_capacity=config.decode_capacity,
                )
            if report.get("status") != "passed":
                report["acceptance"]["status"] = "failed"
            write_json(root / "v1-v10.json", report["acceptance"])
            print(
                "FULL_ACCEPTANCE "
                + json.dumps(
                    dict(
                        status=report["acceptance"]["status"],
                        stability=report["acceptance"]["stability"],
                        long_generation=report["acceptance"]["long_generation"],
                        timeout_fail_stop=report["acceptance"]["timeout_fail_stop"],
                        paired_cleanup=report["acceptance"]["paired_cleanup"],
                        checks={
                            key: value["status"]
                            for key, value in report["acceptance"]["checks"].items()
                        },
                        report=str(root / "v1-v10.json"),
                    )
                ),
                flush=True,
            )
        write_json(root / "summary.json", report)
        if args.role == "prefill":
            write_json(root.parent / "summary.json", report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
