"""Sparsity-driven KV offload manager for the Ascend backend."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, List, Optional, Union

import torch
from sgl_kernel_npu.sparsity_driven_kv_offload import (
    create_shm_tensor,
    slot_map_lookup,
)
from sglang.srt.hardware_backend.npu.kv_rows import derive_kv_rows
from sglang.srt.hardware_backend.npu.mempool.multibase import TensorCopy

from .config import SparseKVOffloadMode

if TYPE_CHECKING:
    import torch.npu
    from sglang.srt.hardware_backend.npu.mempool.runtime import MempoolRuntime
    from sglang.srt.layers.radix_attention import RadixAttention
    from sglang.srt.managers.schedule_batch import Req
    from sglang.srt.mem_cache.allocator import BaseTokenToKVPoolAllocator
    from sglang.srt.mem_cache.memory_pool import ReqToTokenPool
    from sglang.srt.model_executor.forward_batch_info import ForwardBatch

logger = logging.getLogger(__name__)


def _record_stream_event(stream, event) -> None:
    if hasattr(stream, "record_event"):
        stream.record_event(event)
    else:
        event.record(stream)


def _wait_stream_event(stream, event) -> None:
    if hasattr(stream, "wait_event"):
        stream.wait_event(event)
    else:
        event.wait(stream)


def normalize_batch_topk_indices(topk_indices: torch.Tensor) -> torch.Tensor:
    """Normalize DSA top-k indices to [batch, topk] for compact KV copies."""
    if topk_indices.dim() == 2:
        return topk_indices
    if topk_indices.dim() == 3 and topk_indices.shape[1] == 1:
        return topk_indices[:, 0, :]
    if (
        topk_indices.dim() == 4
        and topk_indices.shape[1] == 1
        and topk_indices.shape[2] == 1
    ):
        return topk_indices[:, 0, 0, :]
    raise RuntimeError(
        "Sparsity-driven KV offload expects DSA top-k indices with shape "
        f"[batch, topk], [batch, 1, topk], or [batch, 1, 1, topk], got "
        f"{tuple(topk_indices.shape)}."
    )


class SparseKVCacheManager:
    copy_stream = None
    miss_shm_cpu_tensor: list = []
    miss_shm_dev_ptr: Optional[int] = None
    miss_shm_shape: list = []
    miss_shm_dtype: list = []

    def __init__(
        self,
        req_to_token_pool: ReqToTokenPool,
        token_to_kv_pool_allocator: BaseTokenToKVPoolAllocator,
        sparse_context_len: int,
        *,
        mode: SparseKVOffloadMode,
    ) -> None:
        from sglang.srt.constants import GPU_MEMORY_TYPE_KV_CACHE
        from sglang.srt.mem_cache.memory_pool import MLATokenToKVPool
        from sglang.srt.utils.torch_memory_saver_adapter import TorchMemorySaverAdapter

        # Resource construction is also used by standalone verification. The
        # model runner and attention backend guard unsupported service modes.
        if not mode.uses_sparse_kv_cache:
            raise ValueError("SparseKVCacheManager requires a sparse HBM cache mode")
        self.mode = mode
        self.tensor_copy = TensorCopy()
        enable_memory_saver = False
        memory_saver_adapter = TorchMemorySaverAdapter.create(
            enable=enable_memory_saver
        )

        self.req_to_token_pool = req_to_token_pool
        self.token_to_kv_pool_allocator = token_to_kv_pool_allocator

        # Include the padding row because real request IDs can equal the
        # configured capacity when row 0 is reserved for graph padding.
        self.size = int(req_to_token_pool.req_to_token.shape[0])
        self.max_context_len = req_to_token_pool.max_context_len
        self.sparse_context_len = int(sparse_context_len)
        if self.sparse_context_len <= 0:
            raise ValueError(
                "SparseKVCacheManager requires a positive sparse_context_len, "
                f"got {self.sparse_context_len}."
            )
        self.device = req_to_token_pool.device
        paged_kv_cache = token_to_kv_pool_allocator.get_kvcache()
        if not isinstance(paged_kv_cache, MLATokenToKVPool):
            raise TypeError(
                "SparseKVCacheManager requires an MLATokenToKVPool, "
                f"got {type(paged_kv_cache).__name__}"
            )
        self.paged_kv_cache = paged_kv_cache
        self.start_layer = paged_kv_cache.start_layer
        # MLA params
        self.head_num = 1
        self.kv_lora_rank = self.paged_kv_cache.kv_lora_rank
        self.qk_rope_head_dim = self.paged_kv_cache.qk_rope_head_dim
        # kv_cache_dim = kv_lora_rank + qk_rope_head_dim
        self.head_dim = (
            self.paged_kv_cache.kv_lora_rank + self.paged_kv_cache.qk_rope_head_dim
        )
        self.store_dtype = self.paged_kv_cache.store_dtype
        self.layer_num = self.paged_kv_cache.layer_num
        self._materialize_d2d_hit_stream = torch.npu.Stream()
        self._materialize_h2d_miss_stream = torch.npu.Stream()
        self._materialize_refill_stream = torch.npu.Stream()
        self._materialize_slot_map_stream = torch.npu.Stream()

        self.hit_done = torch.npu.Event()
        self.miss_done = torch.npu.Event()
        self.refill_done = torch.npu.Event()
        self.slot_map_done = torch.npu.Event()

        # device KV buffer
        try:
            with memory_saver_adapter.region(GPU_MEMORY_TYPE_KV_CACHE):
                # [bs, ctx_len, head_num, head_dim] for each layer
                # The padded slot 0 is used for writing dummy outputs from padded tokens.
                self.device_kv_buffer: list[torch.Tensor] = [
                    torch.empty(
                        (
                            self.size,
                            self.sparse_context_len,
                            self.head_num,
                            self.head_dim,
                        ),
                        dtype=self.store_dtype,
                        device=self.device,
                    )
                    for _ in range(self.layer_num)
                ]
        except Exception as e:
            self._raise_buffer_allocation_error("device_kv_buffer", e)

        try:
            with memory_saver_adapter.region(GPU_MEMORY_TYPE_KV_CACHE):
                # Reserve the last row for padded requests and ensure token index
                # `max_context_len` is a valid sentinel column for masked writes.
                # The row width is also aligned to eight int32 values (32 bytes).
                self.device_slot_map: list[torch.Tensor] = [
                    torch.full(
                        (
                            self.size + 1,
                            (self.max_context_len // 8 + 1) * 8,
                        ),
                        -1,
                        dtype=torch.int32,
                        device=self.device,
                    )
                    for _ in range(self.layer_num)
                ]
                # Pre-filled all-(-1) template used to reset the slot map with a
                # fast device-to-device copy instead of an indexed fill.
                self._device_slot_map_minus_one = torch.full_like(
                    self.device_slot_map[0], -1
                )
        except Exception as e:
            self._raise_buffer_allocation_error("device_slot_map", e)

        # Host KV buffer
        # [bs, ctx_len, head_num, head_dim] for each layer
        # The padded slot 0 is used for writing dummy outputs from padded tokens.
        self.host_kv_buffer: list[torch.Tensor] = []
        self.host_ptr_list: list[int] = []
        self.dev_ptr_list: list[int] = []

        self.host_kv_ctx_len: Optional[torch.Tensor] = None
        if mode.uses_host_kv_offload:
            host_kv_shape = (
                self.size,
                self.max_context_len,
                self.head_num,
                self.head_dim,
            )
            logger.info("Sparse KV host buffer shape: %s", host_kv_shape)
            device_id = torch.npu.current_device()

            try:
                for layer_idx in range(self.layer_num):
                    shm_cpu_tensor, host_ptr, dev_ptr = create_shm_tensor(
                        shape=host_kv_shape,
                        dtype=self.store_dtype,
                        device_id=device_id,
                        name=f"host_kv_layer_{layer_idx}_rank_{device_id}",
                    )
                    self.host_kv_buffer.append(shm_cpu_tensor)
                    self.host_ptr_list.append(host_ptr)
                    self.dev_ptr_list.append(dev_ptr)
            except Exception as e:
                self._raise_buffer_allocation_error("host_kv_buffer", e)
            self.host_kv_ctx_len = torch.zeros(
                (self.size, self.max_context_len), dtype=torch.int32, device="cpu"
            )
        self.topk_indices_cpu = None
        self.token_on_device_cpu = None
        self.device_token_pos_cpu = None
        self.current_req_indices_cpu = None

        self._device_cache_slot_ids = torch.arange(
            self.sparse_context_len, dtype=torch.long, device=self.device
        )
        self._slot_map_width = (self.max_context_len // 8 + 1) * 8
        self.pd_decode_k_staging: Optional[list[torch.Tensor]] = None
        self.pd_decode_v_staging: Optional[list[torch.Tensor]] = None
        self._pd_decode_staging_token_capacity = self.max_context_len
        self._pd_decode_copy_stream = (
            torch.npu.Stream() if mode.uses_pd_decode_staging else None
        )
        # Empty containers keep release hooks uniform; only the staging path
        # records host-copy metadata for live requests.
        self._pd_room_to_req_pool_idx: dict[int, int] = {}
        self._pd_room_to_input_len: dict[int, int] = {}
        self._pd_req_pool_idx_to_room: dict[int, int] = {}

        self._install_req_alloc_hook(req_to_token_pool)

    def _require_host_kv(self) -> None:
        if not self.mode.uses_host_kv_offload:
            raise RuntimeError(f"Sparse host KV is disabled in mode={self.mode.value}")

    def _require_pd_decode_staging(self) -> None:
        if not self.mode.uses_pd_decode_staging:
            raise RuntimeError(
                f"Sparse PD decode staging is disabled in mode={self.mode.value}"
            )

    def _raise_buffer_allocation_error(
        self,
        buffer_name: str,
        exc: Exception,
    ) -> None:
        raise RuntimeError(
            "Failed to allocate sparse KV buffer "
            f"{buffer_name}: req_capacity={self.size}, "
            f"max_context_len={self.max_context_len}, "
            f"sparse_context_len={self.sparse_context_len}. "
            "The sparse KV request capacity may be too large; set a smaller "
            "--max-running-requests for sparse KV offload."
        ) from exc

    def _pd_decode_k_buffer_shape(self, slot_count: int) -> tuple[int, int, int, int]:
        return (
            int(slot_count),
            int(self._pd_decode_staging_token_capacity),
            self.head_num,
            self.kv_lora_rank,
        )

    def _pd_decode_v_buffer_shape(self, slot_count: int) -> tuple[int, int, int, int]:
        return (
            int(slot_count),
            int(self._pd_decode_staging_token_capacity),
            self.head_num,
            self.qk_rope_head_dim,
        )

    def _alloc_pd_device_buffers(
        self,
        slot_count: int,
        buffer_name: str,
        shape: tuple[int, int, int, int],
        fill_value: float,
    ) -> list[torch.Tensor]:
        from sglang.srt.constants import GPU_MEMORY_TYPE_KV_CACHE
        from sglang.srt.utils.torch_memory_saver_adapter import TorchMemorySaverAdapter

        enable_memory_saver = False
        memory_saver_adapter = TorchMemorySaverAdapter.create(
            enable=enable_memory_saver
        )
        try:
            with memory_saver_adapter.region(GPU_MEMORY_TYPE_KV_CACHE):
                return [
                    torch.full(
                        shape,
                        fill_value,
                        dtype=self.store_dtype,
                        device=self.device,
                    )
                    for _ in range(self.layer_num)
                ]
        except Exception as e:
            self._raise_buffer_allocation_error(buffer_name, e)

    def ensure_pd_decode_staging_buffers(
        self,
        slot_count: int = 1,
        page_size: Optional[int] = None,
    ) -> None:
        self._require_pd_decode_staging()
        slot_count = int(slot_count)
        if slot_count <= 0:
            raise ValueError(
                f"Sparse KV PD decode slot_count must be > 0: {slot_count}"
            )

        transfer_page_size = int(page_size or self.paged_kv_cache.page_size)
        if transfer_page_size <= 0:
            raise ValueError(
                "Sparse KV PD decode transfer page_size must be positive, "
                f"got {transfer_page_size}."
            )
        aligned_capacity = (
            (self.max_context_len + transfer_page_size - 1)
            // transfer_page_size
            * transfer_page_size
        )
        if self.pd_decode_k_staging is not None or self.pd_decode_v_staging is not None:
            if self.pd_decode_k_staging is None or self.pd_decode_v_staging is None:
                raise RuntimeError(
                    "Sparse KV PD decode staging buffers are partially initialized."
                )
            current_slots = int(self.pd_decode_k_staging[0].shape[0])
            current_capacity = int(self.pd_decode_k_staging[0].shape[1])
            if current_slots < slot_count or current_capacity < aligned_capacity:
                raise RuntimeError(
                    "Sparse KV PD decode staging was already initialized with "
                    f"shape={tuple(self.pd_decode_k_staging[0].shape)}, cannot "
                    f"grow to slots={slot_count}, capacity={aligned_capacity}."
                )
            return

        self._pd_decode_staging_token_capacity = aligned_capacity
        logger.info(
            "Sparse KV PD decode HBM staging buffer shapes: k=%s, v=%s",
            self._pd_decode_k_buffer_shape(slot_count),
            self._pd_decode_v_buffer_shape(slot_count),
        )
        self.pd_decode_k_staging = self._alloc_pd_device_buffers(
            slot_count,
            "pd_decode_k_staging",
            self._pd_decode_k_buffer_shape(slot_count),
            4444.44,
        )
        self.pd_decode_v_staging = self._alloc_pd_device_buffers(
            slot_count,
            "pd_decode_v_staging",
            self._pd_decode_v_buffer_shape(slot_count),
            5555.55,
        )

    def get_pd_decode_transfer_buf_infos(
        self,
        page_size: Optional[int] = None,
    ) -> tuple[list[int], list[int], list[int]]:
        self._require_pd_decode_staging()
        if self.pd_decode_k_staging is None or self.pd_decode_v_staging is None:
            raise RuntimeError("Sparse KV PD decode staging buffer is not initialized.")
        transfer_page_size = int(page_size or self.paged_kv_cache.page_size)
        if transfer_page_size <= 0:
            raise ValueError(
                "Sparse KV PD decode transfer page_size must be positive, "
                f"got {transfer_page_size}."
            )
        return (
            [buf.data_ptr() for buf in self.pd_decode_k_staging]
            + [buf.data_ptr() for buf in self.pd_decode_v_staging],
            [buf.nbytes for buf in self.pd_decode_k_staging]
            + [buf.nbytes for buf in self.pd_decode_v_staging],
            [buf[0, 0].nbytes * transfer_page_size for buf in self.pd_decode_k_staging]
            + [
                buf[0, 0].nbytes * transfer_page_size
                for buf in self.pd_decode_v_staging
            ],
        )

    def get_pd_decode_staging_token_capacity(self) -> int:
        self._require_pd_decode_staging()
        return int(self._pd_decode_staging_token_capacity)

    def get_pd_decode_pages_per_slot(self, page_size: Optional[int] = None) -> int:
        transfer_page_size = int(page_size or self.paged_kv_cache.page_size)
        if transfer_page_size <= 0:
            raise ValueError(
                "Sparse KV PD decode transfer page_size must be positive, "
                f"got {transfer_page_size}."
            )
        return self.get_pd_decode_staging_token_capacity() // transfer_page_size

    def record_pd_request_metadata(self, req: Req) -> None:
        if not self.mode.uses_pd_decode_staging:
            return
        bootstrap_room = getattr(req, "bootstrap_room", None)
        req_pool_idx = req.kv.req_pool_idx
        if bootstrap_room is None or req_pool_idx is None:
            return
        room = int(bootstrap_room)
        pool_idx = int(req_pool_idx)
        input_len = int(len(req.origin_input_ids))
        old_room = self._pd_req_pool_idx_to_room.get(pool_idx)
        if old_room is not None and old_room != room:
            self.clear_pd_request_metadata(bootstrap_room=old_room)
        self._pd_room_to_req_pool_idx[room] = pool_idx
        self._pd_room_to_input_len[room] = input_len
        self._pd_req_pool_idx_to_room[pool_idx] = room

    def clear_pd_request_metadata(
        self,
        bootstrap_room: Optional[int] = None,
        req_pool_idx: Optional[int] = None,
    ) -> None:
        if bootstrap_room is None and req_pool_idx is not None:
            bootstrap_room = self._pd_req_pool_idx_to_room.pop(int(req_pool_idx), None)
        if bootstrap_room is None:
            return
        room = int(bootstrap_room)
        pool_idx = self._pd_room_to_req_pool_idx.pop(room, None)
        self._pd_room_to_input_len.pop(room, None)
        if pool_idx is not None:
            self._pd_req_pool_idx_to_room.pop(int(pool_idx), None)

    def clear_all_pd_request_metadata(self) -> None:
        self._pd_room_to_req_pool_idx.clear()
        self._pd_room_to_input_len.clear()
        self._pd_req_pool_idx_to_room.clear()

    def get_pd_copy_metadata(
        self,
        bootstrap_room: int,
        decode_prefix_len: int = 0,
    ) -> tuple[int, int]:
        self._require_pd_decode_staging()
        room = int(bootstrap_room)
        if room not in self._pd_room_to_req_pool_idx:
            raise RuntimeError(
                f"Sparse KV PD metadata for bootstrap_room={room} is not recorded."
            )
        req_pool_idx = self._pd_room_to_req_pool_idx[room]
        input_len = self._pd_room_to_input_len[room]
        token_count = input_len - int(decode_prefix_len)
        if token_count < 0:
            raise RuntimeError(
                "Sparse KV PD got negative token_count from metadata: "
                f"input_len={input_len}, decode_prefix_len={decode_prefix_len}."
            )
        return req_pool_idx, token_count

    def offload_pd_decode_staging_to_host(
        self,
        slot_id: int,
        req_pool_idx: int,
        token_count: int,
        stream: Optional[torch.npu.Stream] = None,
    ) -> None:
        self._require_pd_decode_staging()
        if self.pd_decode_k_staging is None or self.pd_decode_v_staging is None:
            raise RuntimeError("Sparse KV PD decode staging buffer is not initialized.")
        slot_id = int(slot_id)
        req_pool_idx = int(req_pool_idx)
        token_count = int(token_count)
        slot_count = int(self.pd_decode_k_staging[0].shape[0])
        if slot_id < 0 or slot_id >= slot_count:
            raise RuntimeError(
                f"Sparse KV PD decode got slot_id={slot_id}, outside slot_count "
                f"{slot_count}."
            )
        if req_pool_idx < 0 or req_pool_idx >= self.size:
            raise RuntimeError(
                f"Sparse KV PD decode got req_pool_idx={req_pool_idx}, outside "
                f"sparse pool size {self.size}."
            )
        if token_count < 0 or token_count > self.max_context_len:
            raise RuntimeError(
                f"Sparse KV PD decode got token_count={token_count}, outside "
                f"max_context_len {self.max_context_len}."
            )

        assert self.host_kv_ctx_len is not None
        self.host_kv_ctx_len[req_pool_idx] = token_count
        self.reset_requests([req_pool_idx])
        if token_count == 0:
            return

        actual_stream = stream if stream is not None else self._pd_decode_copy_stream
        assert actual_stream is not None
        with torch.npu.stream(actual_stream):
            for layer_idx in range(self.layer_num):
                dst = self.host_kv_buffer[layer_idx][req_pool_idx, :token_count]
                dst[..., : self.kv_lora_rank].copy_(
                    self.pd_decode_k_staging[layer_idx][slot_id, :token_count],
                    non_blocking=False,
                )
                dst[..., self.kv_lora_rank :].copy_(
                    self.pd_decode_v_staging[layer_idx][slot_id, :token_count],
                    non_blocking=False,
                )
        actual_stream.synchronize()

    def init_req(self, req: Req) -> None:
        if getattr(req, "inflight_middle_chunks", getattr(req, "is_chunked", 0)) > 0:
            return
        rid = req.kv.req_pool_idx
        if rid is None:
            raise RuntimeError(
                "Cannot initialize sparse KV state before allocating a request pool slot"
            )
        if self.host_kv_ctx_len is not None:
            self.host_kv_ctx_len[rid] = len(req.origin_input_ids)
        self.reset_requests([rid])

    def reset_requests(self, req_ids: List[int]) -> None:
        if not req_ids:
            return

        req_ids_tensor = torch.tensor(
            req_ids, dtype=torch.long, device=self.device
        ).contiguous()
        for layer_idx in range(self.layer_num):
            self.device_slot_map[layer_idx].index_fill_(0, req_ids_tensor, -1)

    def _install_req_alloc_hook(self, req_to_token_pool: ReqToTokenPool) -> None:
        original_alloc = getattr(
            req_to_token_pool, "_sparse_kv_original_alloc", req_to_token_pool.alloc
        )
        setattr(req_to_token_pool, "_sparse_kv_original_alloc", original_alloc)
        original_free = getattr(
            req_to_token_pool, "_sparse_kv_original_free", req_to_token_pool.free
        )
        setattr(req_to_token_pool, "_sparse_kv_original_free", original_free)
        original_clear = getattr(
            req_to_token_pool, "_sparse_kv_original_clear", req_to_token_pool.clear
        )
        setattr(req_to_token_pool, "_sparse_kv_original_clear", original_clear)

        def alloc_with_sparse_reset(reqs: list[Req]) -> Optional[List[int]]:
            newly_allocated = [req.kv.req_pool_idx is None for req in reqs]
            req_pool_indices = original_alloc(reqs)
            if req_pool_indices is not None:
                self.reset_requests(
                    [
                        req_pool_indices[i]
                        for i, is_new in enumerate(newly_allocated)
                        if is_new
                    ]
                )
                for req in reqs:
                    self.record_pd_request_metadata(req)
            return req_pool_indices

        def free_with_sparse_clear(req: Req):
            self.clear_pd_request_metadata(req_pool_idx=req.kv.req_pool_idx)
            return original_free(req)

        def clear_with_sparse_clear():
            self.clear_all_pd_request_metadata()
            for slot_map in self.device_slot_map:
                slot_map.copy_(self._device_slot_map_minus_one)
            if self.host_kv_ctx_len is not None:
                self.host_kv_ctx_len.zero_()
            return original_clear()

        setattr(req_to_token_pool, "alloc", alloc_with_sparse_reset)
        setattr(req_to_token_pool, "free", free_with_sparse_clear)
        setattr(req_to_token_pool, "clear", clear_with_sparse_clear)

    def offload(
        self,
        k: torch.Tensor,
        k_rope: torch.Tensor,
        layer: RadixAttention,
        forward_batch: ForwardBatch,
        stream: torch.npu.Stream,
    ):
        self._require_host_kv()
        layer_idx = layer.layer_id - self.start_layer
        device = k.device

        # k:        [total_token_slots, nhead, dim]
        # k_rope:   [total_token_slots, nhead, dim]
        # kv_device: [total_token_slots, nhead, 2*dim]
        kv_device = torch.cat([k, k_rope], dim=-1)

        # Source row indices into kv_device.
        # In graph mode this tensor is expected to have a static shape.
        src_token_indices = forward_batch.out_cache_loc.to(torch.long).contiguous()
        static_token_slots = int(src_token_indices.numel())

        if forward_batch.forward_mode.is_decode():
            # decode graph mode:
            # one token slot per request, padded requests are masked out
            req_ids = forward_batch.req_pool_indices.to(torch.long)
            token_pos = (forward_batch.seq_lens - 1).to(torch.long)

            dst_token_indices = (
                req_ids * self.max_context_len + token_pos
            ).contiguous()

            # Existing graph decode convention:
            # padded decode requests carry seq_len == 1.
            valid_mask = (
                (forward_batch.seq_lens != 1)
                & (src_token_indices >= 0)
                & (req_ids >= 0)
            ).contiguous()

        else:
            # prefill graph mode:
            # assume out_cache_loc is laid out as [B, TOKENS_PER_REQ] flattened row-major
            if (
                forward_batch.extend_seq_lens is None
                or forward_batch.extend_prefix_lens is None
            ):
                raise RuntimeError(
                    "Sparse graph prefill offload requires extend_seq_lens and "
                    "extend_prefix_lens in ForwardBatch."
                )

            batch_size = int(forward_batch.req_pool_indices.shape[0])
            if batch_size <= 0:
                return

            if static_token_slots % batch_size != 0:
                raise RuntimeError(
                    f"out_cache_loc length {static_token_slots} is not divisible by "
                    f"batch size {batch_size}. Cannot infer graph static token layout."
                )

            tokens_per_req = static_token_slots // batch_size

            req_ids = forward_batch.req_pool_indices.to(torch.long)
            extend_seq_lens = forward_batch.extend_seq_lens.to(torch.long)
            extend_prefix_lens = forward_batch.extend_prefix_lens.to(torch.long)

            local_offsets = (
                torch.arange(
                    tokens_per_req,
                    device=device,
                    dtype=torch.long,
                )
                .unsqueeze(0)
                .expand(batch_size, tokens_per_req)
            )

            req_ids_2d = req_ids.unsqueeze(1).expand(batch_size, tokens_per_req)
            dst_pos_2d = extend_prefix_lens.unsqueeze(1) + local_offsets

            dst_token_indices = (
                (req_ids_2d * self.max_context_len + dst_pos_2d)
                .reshape(-1)
                .contiguous()
            )

            valid_mask = (
                (local_offsets < extend_seq_lens.unsqueeze(1)).reshape(-1)
                & (src_token_indices >= 0)
                & (req_ids_2d.reshape(-1) >= 0)
            ).contiguous()

        # Layout check:
        # kv_device rows:                 [token_slot]
        # host_kv_buffer[layer] rows:     [req_id, seq_pos]
        # block dims must match on [nhead, 2*dim]
        assert kv_device.shape[1:] == self.host_kv_buffer[layer_idx].shape[2:]
        # torch.npu.synchronize()
        actual_stream = stream if stream is not None else torch.npu.current_stream()
        with torch.npu.stream(actual_stream):
            self.tensor_copy(
                kv_device,
                self.host_kv_buffer[layer_idx],
                src_token_indices,
                dst_token_indices,
                valid_mask,
                1,  # kv_device: [token_slot, nhead, 2*dim]
                2,  # host_kv_buffer: [num_req, max_context_len, nhead, 2*dim]
                copy_key=("offload_v1", layer_idx),
                block_dim=48,
                dst_ptr=self.dev_ptr_list[layer_idx],
            )
        # torch.npu.synchronize()

    def offload_v2(
        self,
        k: torch.Tensor,
        k_rope: torch.Tensor,
        layer: RadixAttention,
        forward_batch: ForwardBatch,
        stream: torch.npu.Stream,
    ):
        """Offload compact per-forward KV rows into the sparse host KV buffer.

        v1 expects k/k_rope to be full native KV-cache views and therefore uses
        forward_batch.out_cache_loc as source rows. v2 expects k/k_rope to be
        compact rows produced by the current forward pass, so source rows are
        simply [0, num_new_tokens). The native cache slot is kept only as
        validity metadata.

        Keep src_tensor/dst_tensor/src_index/dst_index/valid_mask explicit so
        the final copy can be swapped to a custom kernel without changing the
        graph-friendly index construction.
        """
        self._require_host_kv()
        layer_idx = layer.layer_id - self.start_layer
        device = k.device

        # k:         [num_new_tokens, nhead, kv_lora_rank]
        # k_rope:    [num_new_tokens, nhead, qk_rope_head_dim]
        # kv_device: [num_new_tokens, nhead, kv_lora_rank + qk_rope_head_dim]
        src_tensor = torch.cat([k, k_rope], dim=-1).contiguous()
        dst_tensor = self.host_kv_buffer[layer_idx]
        src_index = torch.arange(src_tensor.shape[0], device=device, dtype=torch.long)
        num_src_rows = int(src_tensor.shape[0])

        if (
            not forward_batch.forward_mode.is_decode()
            and not forward_batch.req_pool_indices.numel()
        ):
            return
        req_ids, token_pos, valid_mask = derive_kv_rows(
            num_src_rows,
            is_decode=forward_batch.forward_mode.is_decode(),
            max_context_len=self.max_context_len,
            req_pool_indices=forward_batch.req_pool_indices,
            seq_lens=forward_batch.seq_lens,
            out_cache_loc=forward_batch.out_cache_loc,
            extend_seq_lens=forward_batch.extend_seq_lens,
            extend_prefix_lens=forward_batch.extend_prefix_lens,
            extend_seq_lens_cpu=forward_batch.extend_seq_lens_cpu,
            global_num_token_non_padded_cpu=forward_batch.global_num_token_non_padded_cpu,
        )
        dst_index = torch.where(
            valid_mask, req_ids * self.max_context_len + token_pos, 0
        ).contiguous()

        assert src_tensor.shape[1:] == dst_tensor.shape[2:]
        assert src_index.shape == dst_index.shape == valid_mask.shape

        actual_stream = stream if stream is not None else torch.npu.current_stream()
        with torch.npu.stream(actual_stream):
            self.tensor_copy(
                src_tensor,
                dst_tensor,
                src_index,
                dst_index,
                valid_mask,
                1,  # src_tensor: [num_new_tokens, nhead, head_dim]
                2,  # dst_tensor: [num_req, max_context_len, nhead, head_dim]
                copy_key=("offload_v2", layer_idx),
                block_dim=48,
                dst_ptr=self.dev_ptr_list[layer_idx],
            )

    def get_forward_kv(
        self,
        layer: Union[RadixAttention, int],
        forward_batch: ForwardBatch,
        stream: Optional[torch.npu.Stream] = None,
    ):
        """Gather full request KV from sparse storage as compact TND tensors.

        This helper is intended for the prefill/extend sparse path. It returns
        KV in the same request order as forward_batch.req_pool_indices:
        [req0 tokens][req1 tokens]... . The SFA caller should pair this with
        actual_seq_lengths_kv = cumsum(forward_batch.seq_lens).

        TODO: Add a prefill-resident device KV cache shaped like
        [max_prefill_parallel_reqs, max_prefill_len, nhead, head_dim]. Reuse a
        slot while the same req_id continues chunked prefill, and fully
        overwrite it when a new req_id takes that slot. This mirrors the decode
        device cache idea and avoids repeatedly copying the full prefix KV from
        host for every chunk.
        """
        self._require_host_kv()
        layer_id = layer.layer_id if hasattr(layer, "layer_id") else int(layer)
        layer_idx = layer_id - self.start_layer
        if layer_idx < 0 or layer_idx >= self.layer_num:
            raise RuntimeError(
                f"Invalid sparse KV layer id {layer_id}; start_layer="
                f"{self.start_layer}, layer_num={self.layer_num}."
            )

        if forward_batch.req_pool_indices is None or forward_batch.seq_lens is None:
            raise RuntimeError(
                "get_forward_kv requires req_pool_indices and seq_lens in ForwardBatch."
            )

        device = (
            forward_batch.req_pool_indices.device
            if forward_batch.req_pool_indices.device.type == "npu"
            else self.device
        )
        req_ids = forward_batch.req_pool_indices.to(device=device, dtype=torch.long)
        seq_lens = forward_batch.seq_lens.to(device=device, dtype=torch.long)

        if int(req_ids.numel()) != int(seq_lens.numel()):
            raise RuntimeError(
                "get_forward_kv expects req_pool_indices and seq_lens to have the "
                f"same length, got {int(req_ids.numel())} and "
                f"{int(seq_lens.numel())}."
            )

        valid_reqs = (seq_lens > 0) & (req_ids >= 0)
        req_ids = req_ids[valid_reqs].contiguous()
        seq_lens = seq_lens[valid_reqs].contiguous()

        if int(seq_lens.numel()) == 0:
            empty_nope = torch.empty(
                (0, self.head_num, self.kv_lora_rank),
                dtype=self.store_dtype,
                device=device,
            )
            empty_pe = torch.empty(
                (0, self.head_num, self.qk_rope_head_dim),
                dtype=self.store_dtype,
                device=device,
            )
            return empty_nope, empty_pe

        if bool((req_ids >= self.size).any().item()):
            raise RuntimeError(
                f"get_forward_kv got req id outside sparse pool size {self.size}."
            )
        if bool((seq_lens > self.max_context_len).any().item()):
            raise RuntimeError(
                "get_forward_kv got seq_len larger than max_context_len "
                f"{self.max_context_len}."
            )

        total_tokens = int(seq_lens.sum().item())
        kv_cat = torch.empty(
            (total_tokens, self.head_num, self.head_dim),
            dtype=self.store_dtype,
            device=device,
        )

        seq_starts = torch.cumsum(seq_lens, dim=0) - seq_lens
        src_req_ids = torch.repeat_interleave(
            req_ids, seq_lens, output_size=total_tokens
        )
        src_seq_starts = torch.repeat_interleave(
            seq_starts, seq_lens, output_size=total_tokens
        )
        token_pos = (
            torch.arange(total_tokens, device=device, dtype=torch.long) - src_seq_starts
        )
        src_index = (src_req_ids * self.max_context_len + token_pos).contiguous()
        dst_index = torch.arange(total_tokens, device=device, dtype=torch.long)
        valid_mask = torch.ones(total_tokens, device=device, dtype=torch.bool)

        actual_stream = stream if stream is not None else torch.npu.current_stream()
        with torch.npu.stream(actual_stream):
            self.tensor_copy(
                self.host_kv_buffer[layer_idx],
                kv_cat,
                src_index,
                dst_index,
                valid_mask,
                2,  # host_kv_buffer: [num_req, max_context_len, nhead, head_dim]
                1,  # kv_cat: [total_tokens, nhead, head_dim]
                copy_key=("forward", layer_idx),
                block_dim=48,
                src_ptr=self.dev_ptr_list[layer_idx],
            )

        k_nope, k_pe = kv_cat.split([self.kv_lora_rank, self.qk_rope_head_dim], dim=-1)
        return k_nope.contiguous(), k_pe.contiguous()

    def materialize_selected_kv(
        self,
        layer: RadixAttention,
        forward_batch: ForwardBatch,
        topk_indices: torch.Tensor,
        selected_kv_buffer: torch.Tensor,
        stream: torch.npu.Stream,
        *,
        mempool_runtime: Optional[MempoolRuntime] = None,
    ) -> torch.Tensor:
        """Materialize top-k KV entries and refresh the device cache metadata."""
        if (mempool_runtime is not None) != (
            self.mode is SparseKVOffloadMode.PD_DECODE_MEMPOOL
        ):
            raise RuntimeError("BM fetch runtime must match the formal decode mode")
        layer_idx = layer.layer_id - self.start_layer
        stream = stream if stream is not None else torch.npu.current_stream()
        observe = mempool_runtime is not None and mempool_runtime.observer is not None
        if observe:
            cache_range = torch.npu.mstx.range_start(
                f"mempool:cache_manage:{layer.layer_id}", stream
            )

        with torch.npu.stream(stream):
            topk_indices = normalize_batch_topk_indices(topk_indices)
            batch_size, topk_len = topk_indices.shape
            if tuple(selected_kv_buffer.shape[:2]) != (batch_size, topk_len):
                raise ValueError(
                    "selected KV and top-k must have the same padded row width"
                )
            # Route invalid requests to sentinel rows without changing graph shape.
            # slot_map_row_indices: invalid -> self.size (reserved slot-map row)
            # device_cache_row_indices: invalid -> 0 (masked by valid_topk_mask)
            req_pool_indices = forward_batch.req_pool_indices[:batch_size]
            req_pool_indices = req_pool_indices.to(torch.long).contiguous()
            valid_req_mask = (req_pool_indices > 0) & (req_pool_indices < self.size)
            if forward_batch.seq_lens is not None:
                valid_req_mask = valid_req_mask & (
                    forward_batch.seq_lens[:batch_size] > 0
                )
            slot_map_row_indices = torch.where(
                valid_req_mask,
                req_pool_indices,
                torch.full_like(req_pool_indices, self.size),
            )
            device_cache_row_indices = torch.where(
                valid_req_mask,
                req_pool_indices,
                torch.zeros_like(req_pool_indices),
            )

            # Normalize top-k indices and mask invalid requests and token IDs.
            if topk_len > self.sparse_context_len:
                raise RuntimeError(
                    "DSA top-k length exceeds sparse KV device cache capacity: "
                    f"topk_len={topk_len}, sparse_context_len={self.sparse_context_len}."
                )
            valid_topk_mask = (
                (topk_indices >= 0)
                & (topk_indices < self.max_context_len)
                & valid_req_mask.unsqueeze(1)
            )
            if mempool_runtime is not None:
                # Apply the same binding/written-prefix rule to hits, misses,
                # refill, slot-map updates and the attention lengths.
                valid_topk_mask = mempool_runtime.selected_kv_valid(
                    layer.layer_id, device_cache_row_indices, topk_indices
                )

            # Query the slot map for device-cache hits and their slot positions.
            slot_lookup_req_indices = slot_map_row_indices.to(
                dtype=torch.int32
            ).contiguous()
            slot_lookup_topk_indices = (
                torch.where(valid_topk_mask, topk_indices, -1)
                .to(dtype=torch.int32)
                .contiguous()
            )
            token_on_device, device_token_pos = slot_map_lookup(
                self.device_slot_map[layer_idx],
                slot_lookup_req_indices,
                slot_lookup_topk_indices,
            )
            token_on_device = token_on_device.to(torch.bool) & valid_topk_mask
            if observe:
                torch.npu.mstx.range_end(cache_range)
                sample_range = torch.npu.mstx.range_start(
                    f"mempool:observer:{layer.layer_id}", stream
                )
                mempool_runtime.observation_device.cache(
                    layer.layer_id,
                    device_cache_row_indices,
                    topk_indices,
                    valid_topk_mask,
                    token_on_device,
                )
                torch.npu.mstx.range_end(sample_range)
                cache_range = torch.npu.mstx.range_start(
                    f"mempool:cache_manage:{layer.layer_id}", stream
                )

            # Build copy indices on the main stream, then protect their use on
            # the hit and miss streams with copy_ready.
            hit_src_index, hit_dst_index, hit_valid_mask = _build_hit_src_dst_index(
                token_on_device,
                device_token_pos,
                device_cache_row_indices,
                self.sparse_context_len,
            )

            miss_mask = (~token_on_device) & valid_topk_mask
            if mempool_runtime is None:
                miss_src_index, miss_dst_index, miss_valid_mask = (
                    _build_miss_src_dst_index(
                        miss_mask,
                        topk_indices,
                        device_cache_row_indices,
                        self.max_context_len,
                    )
                )

            cache_slot_ids = self._device_cache_slot_ids[:topk_len]
            request_cache_offsets = (
                device_cache_row_indices.unsqueeze(1) * self.sparse_context_len
            )
            refill_src_index = torch.arange(
                batch_size * topk_len,
                dtype=torch.long,
                device=topk_indices.device,
            )
            refill_dst_index = (
                (request_cache_offsets + cache_slot_ids).reshape(-1).contiguous()
            )
            refill_valid_mask = valid_topk_mask.reshape(-1).contiguous()

            copy_ready = torch.npu.Event()
            if observe:
                torch.npu.mstx.range_end(cache_range)
            _record_stream_event(stream, copy_ready)

        # Copy device-cache hits into the selected KV buffer.
        with torch.npu.stream(self._materialize_d2d_hit_stream):
            _wait_stream_event(self._materialize_d2d_hit_stream, copy_ready)
            if observe:
                hit_range = torch.npu.mstx.range_start(
                    f"mempool:cache_hit:{layer.layer_id}",
                    self._materialize_d2d_hit_stream,
                )
            self.tensor_copy(
                self.device_kv_buffer[layer_idx],
                selected_kv_buffer,
                hit_src_index,
                hit_dst_index,
                hit_valid_mask,
                2,
                2,  #
                copy_key=("hit", layer_idx),
                block_dim=24,
            )
            if observe:
                torch.npu.mstx.range_end(hit_range)
            _record_stream_event(self._materialize_d2d_hit_stream, self.hit_done)

        # Both BM sources run serially on the existing miss stream. Recording
        # one miss_done after both preserves the hit/refill/attention contract.
        with torch.npu.stream(self._materialize_h2d_miss_stream):
            _wait_stream_event(self._materialize_h2d_miss_stream, copy_ready)
            if observe:
                miss_range = torch.npu.mstx.range_start(
                    f"mempool:miss_io:{layer.layer_id}",
                    self._materialize_h2d_miss_stream,
                )
            if mempool_runtime is not None:
                mempool_runtime.fetch_selected_kv(
                    layer.layer_id,
                    device_cache_row_indices,
                    topk_indices,
                    miss_mask,
                    selected_kv_buffer,
                )
            else:
                self.tensor_copy(
                    self.host_kv_buffer[layer_idx],
                    selected_kv_buffer,
                    miss_src_index,
                    miss_dst_index,
                    miss_valid_mask,
                    2,
                    2,
                    copy_key=("miss", layer_idx),
                block_dim=24,
                    src_ptr=self.dev_ptr_list[layer_idx],
                )
            if observe:
                torch.npu.mstx.range_end(miss_range)
            _record_stream_event(self._materialize_h2d_miss_stream, self.miss_done)

        # Refill the device cache with the current top-k after hit and miss
        # copies complete, so the next step can reuse these entries.
        with torch.npu.stream(self._materialize_refill_stream):
            _wait_stream_event(self._materialize_refill_stream, self.hit_done)
            _wait_stream_event(self._materialize_refill_stream, self.miss_done)
            if observe:
                refill_range = torch.npu.mstx.range_start(
                    f"mempool:cache_refill:{layer.layer_id}",
                    self._materialize_refill_stream,
                )
            self.tensor_copy(
                selected_kv_buffer,
                self.device_kv_buffer[layer_idx],
                refill_src_index,
                refill_dst_index,
                refill_valid_mask,
                2,
                2,
                copy_key=("refill", layer_idx),
                block_dim=24,
            )
            if observe:
                torch.npu.mstx.range_end(refill_range)
            _record_stream_event(self._materialize_refill_stream, self.refill_done)

        # Replace the slot-map row with the current top-k mapping. Invalid
        # entries use the max_context_len sentinel column to preserve shape.
        with torch.npu.stream(self._materialize_slot_map_stream):
            _wait_stream_event(self._materialize_slot_map_stream, copy_ready)
            if observe:
                map_range = torch.npu.mstx.range_start(
                    f"mempool:cache_map:{layer.layer_id}",
                    self._materialize_slot_map_stream,
                )
            self.device_slot_map[layer_idx].copy_(self._device_slot_map_minus_one)

            slot_map_token_indices = torch.where(
                valid_topk_mask,
                topk_indices.to(torch.long),
                torch.full_like(topk_indices, self.max_context_len, dtype=torch.long),
            )
            slot_map_slot_values = torch.where(
                valid_topk_mask,
                cache_slot_ids.to(torch.int32),
                torch.full_like(cache_slot_ids, -1, dtype=torch.int32),
            )
            slot_map_flat_indices = (
                slot_map_row_indices.unsqueeze(1) * self._slot_map_width
                + slot_map_token_indices
            ).reshape(-1)
            self.tensor_copy(
                slot_map_slot_values.reshape(-1, 1).contiguous(),
                self.device_slot_map[layer_idx].view(-1, 1),
                torch.arange(
                    slot_map_slot_values.numel(),
                    dtype=torch.long,
                    device=topk_indices.device,
                ),
                slot_map_flat_indices,
                valid_topk_mask.reshape(-1),
                1,
                1,
                copy_key=("slot_map", layer_idx),
                block_dim=48,
            )
            if observe:
                torch.npu.mstx.range_end(map_range)
            _record_stream_event(self._materialize_slot_map_stream, self.slot_map_done)
        return valid_topk_mask


_global_sparse_kv_manager: Optional[SparseKVCacheManager] = None


def register_sparse_kv_manager(manager: SparseKVCacheManager) -> None:
    global _global_sparse_kv_manager
    _global_sparse_kv_manager = manager


def get_sparse_kv_manager() -> Optional[SparseKVCacheManager]:
    return _global_sparse_kv_manager


def _build_hit_src_dst_index(
    token_on_device: torch.Tensor,
    device_token_pos: torch.Tensor,
    current_req_indices: torch.Tensor,
    sparse_context_len: int,
):
    """
    token_on_device: [bs, topk], bool
    device_token_pos: [bs, topk], int64 or int32
    current_req_indices: [bs], int64

    Return:
        src_index_full: [bs * topk], int64
        dst_index_full: [bs * topk], int64
        valid_mask: [bs * topk], bool

    Flattening rule:
        src row = req_id * sparse_context_len + device_token_pos
        dst row = batch_id * topk + topk_pos
    """
    if token_on_device.dim() != 2 or device_token_pos.dim() != 2:
        raise RuntimeError(
            f"token_on_device and device_token_pos must be 2-D, got "
            f"{token_on_device.dim()} and {device_token_pos.dim()}"
        )
    if token_on_device.shape != device_token_pos.shape:
        raise RuntimeError(
            f"token_on_device and device_token_pos must have the same shape, got "
            f"{tuple(token_on_device.shape)} and {tuple(device_token_pos.shape)}"
        )
    if current_req_indices.dim() != 1:
        raise RuntimeError(
            f"current_req_indices must be 1-D, got {current_req_indices.dim()}"
        )

    bs, topk = token_on_device.shape
    if current_req_indices.numel() != bs:
        raise RuntimeError(
            f"current_req_indices length mismatch: "
            f"{current_req_indices.numel()} vs batch {bs}"
        )
    if sparse_context_len <= 0:
        raise RuntimeError(
            f"sparse_context_len must be positive, got {sparse_context_len}"
        )

    device = token_on_device.device

    valid_mask = token_on_device.reshape(-1).contiguous()

    flat_dst_index_all = torch.arange(
        bs * topk,
        device=device,
        dtype=torch.int64,
    )

    req_offsets = current_req_indices.to(torch.int64).unsqueeze(1) * sparse_context_len
    src_index_2d = req_offsets + device_token_pos.to(torch.int64)
    flat_src_index_all = src_index_2d.reshape(-1).contiguous()

    return flat_src_index_all, flat_dst_index_all, valid_mask


def _build_miss_src_dst_index(
    token_from_host: torch.Tensor,
    topk_indices: torch.Tensor,
    current_req_indices: torch.Tensor,
    max_context_len: int,
):
    if token_from_host.dim() != 2 or topk_indices.dim() != 2:
        raise RuntimeError(
            f"token_from_host and topk_indices must be 2-D, got "
            f"{token_from_host.dim()} and {topk_indices.dim()}"
        )
    if token_from_host.shape != topk_indices.shape:
        raise RuntimeError(
            f"token_from_host and topk_indices must have the same shape, got "
            f"{tuple(token_from_host.shape)} and {tuple(topk_indices.shape)}"
        )
    if current_req_indices.dim() != 1:
        raise RuntimeError(
            f"current_req_indices must be 1-D, got {current_req_indices.dim()}"
        )
    if current_req_indices.numel() != token_from_host.shape[0]:
        raise RuntimeError(
            f"current_req_indices length mismatch: "
            f"{current_req_indices.numel()} vs batch {token_from_host.shape[0]}"
        )

    bs, topk = token_from_host.shape
    device = token_from_host.device

    valid_2d = token_from_host & (topk_indices >= 0) & (topk_indices < max_context_len)
    valid_mask = valid_2d.reshape(-1).contiguous()

    flat_dst_index_all = torch.arange(
        bs * topk,
        device=device,
        dtype=torch.int64,
    )

    req_offsets = current_req_indices.to(torch.int64).unsqueeze(1) * max_context_len
    src_index_2d = req_offsets + topk_indices.to(torch.int64)
    flat_src_index_all = src_index_2d.reshape(-1).contiguous()

    return flat_src_index_all, flat_dst_index_all, valid_mask
