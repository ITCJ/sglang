"""Retain prompt pages independently of alive slots and native request rows."""

from __future__ import annotations

import copy
import hashlib
import importlib
import json
import logging
import os
from contextlib import nullcontext
from pathlib import Path
from typing import Any, Callable

import msgspec
import torch
from torch import Tensor

from .indexed_copy import copy_rows
from .layout import check_index, positive_int
from .multibase import IndexedCopy
from .manager import MempoolKVManager
from .observation import write_evidence
from .page_write import PageWriter
from .pool_copy import CopyBlock, CopyTask, PoolCopyExecutor
from .split_read import assign_prefix_pages

logger = logging.getLogger(__name__)


def log_prefix_content(record: dict[str, Any]) -> None:
    """Keep large acceptance records out of the multi-process launcher stream."""
    folder = os.environ.get("SGLANG_NPU_MEMPOOL_EVIDENCE_DIR")
    if folder is None:
        payload = json.dumps(record, sort_keys=True)
        logger.info("mempool prefix_content data=%s", payload)
        return
    relative = write_evidence(record, Path(folder))
    # File is closed before the causal marker; each rank has its own record.
    logger.info(
        "mempool prefix_content_file data=%s", json.dumps(dict(file=str(relative)))
    )


class _Source(msgspec.Struct):
    rid: str
    slot: int
    tokens: int
    values: dict[tuple[str, int], Tensor] = msgspec.field(default_factory=dict)
    coverage: dict[tuple[str, int], Tensor] = msgspec.field(default_factory=dict)
    verified: bool = False


class _Admit(msgspec.Struct):
    rid: str
    op_id: int
    slot: int
    prompt_tokens: int
    source_pages: tuple[int, ...]
    target_pages: tuple[int, ...]
    event: Any = None
    retained: list[Tensor] = msgspec.field(default_factory=list)
    receipt: dict[str, Any] | None = None
    committed: bool = False
    written_pages: list[int] = msgspec.field(default_factory=list)


class _Read(msgspec.Struct):
    rid: str
    op_id: int
    kind: str
    source_pages: tuple[int, ...]
    slot: int
    indices: Tensor | None = None
    pool: Any = None
    event: Any = None
    retained: list[Tensor] = msgspec.field(default_factory=list)
    receipt: dict[str, Any] | None = None
    main_rows: Tensor | None = None
    index_rows: Tensor | None = None
    segment_rows: dict[str, list[int]] = msgspec.field(default_factory=dict)
    read_pages: dict[str, list[int]] = msgspec.field(default_factory=dict)
    gather_width: int = 0


class PrefixStore:
    """Own P's local page reservations and copies, with receipts after NPU completion."""

    def __init__(
        self,
        manager: MempoolKVManager,
        *,
        page_size: int,
        device: str,
        kernel: Any = None,
        event_factory: Callable[[], Any] | None = None,
        verify: bool = False,
        replica: int = 0,
        readers: int = 1,
        read_assignment: str = "round_robin",
        all_gather: Callable[[Tensor, Tensor], None] | None = None,
        scatter_kernel: Any = None,
        page_writer: PageWriter | None = None,
        index_writer: PageWriter | None = None,
        admit_mode: str = "owners",
        admit_rank: int = 0,
        start_segment: int | None = None,
        copy_executor: PoolCopyExecutor | None = None,
    ) -> None:
        positive_int("page_size", page_size)
        layout = manager.layout.prefix_main
        if manager.rank != 0 or layout is None or layout.tokens != page_size:
            raise ValueError("prefix store requires P's configured page regions")
        self.manager, self.page_size, self.device = manager, page_size, device
        self.verify = verify
        self.observer: Any = None
        self.copy_executor = copy_executor
        self.page_writer = page_writer
        self.index_writer = index_writer
        self._prompt_tokens = 0
        self.replica = replica
        self.prefix_layout = manager.session.prefix_layout if manager.session else None
        self.admit_mode, self.admit_rank = admit_mode, admit_rank
        self.start_segment = start_segment
        self._next_segment = 0
        self._request_segment = 0
        self._request_rid: str | None = None
        self.readers, self.read_assignment, self.all_gather = (
            readers,
            read_assignment,
            all_gather,
        )
        self._kernel = kernel
        self._scatter_kernel = scatter_kernel
        self._event_factory = event_factory or (lambda: torch.npu.Event())
        self._free = set(range(layout.slots))
        self._operations: dict[int, _Admit] = {}
        self._reads: dict[int, _Read] = {}
        self._ready: set[int] = set()
        self._read_stream: Any = None
        self._fault: str | None = None
        self._dtype = torch.empty(1, dtype=torch.bfloat16, device="cpu")
        # Acceptance-only CPU references: one current request plus retained pages.
        self._source: _Source | None = None
        self._saved: dict[int, dict[tuple[str, int], Tensor]] = {}
        self._saved_digests: dict[int, dict[str, str]] = {}

    @property
    def free_pages(self) -> tuple[int, ...]:
        return tuple(sorted(self._free))

    def select_pages(self, count: int) -> list[int]:
        """Choose physical pages without changing the current request's start."""
        if self.prefix_layout is not None:
            return self.prefix_layout.select(self._free, count, self._request_segment)
        return list(self.free_pages[:count])

    def complete_admit(self, op_id: int, receipts: list[dict[str, Any]]) -> None:
        """Publish local readiness only after all segment writers have completed."""
        if self.prefix_layout is None:
            return
        operation = self._operations[op_id]
        if len(receipts) != sum(map(len, self.prefix_layout.groups)):
            raise ValueError("prefix admit writer receipts are incomplete")
        for rank, receipt in enumerate(receipts):
            expected = [
                page
                for page in operation.target_pages
                if self._admit_writer(page) == rank
            ]
            if receipt.get("written_pages") != expected or receipt.get(
                "target_pages"
            ) != list(operation.target_pages):
                raise ValueError(
                    "prefix admit writer coverage differs from reserved pages"
                )
        if self.verify:
            canonical: dict[int, dict[str, str]] = {}
            sources: dict[str, dict[str, int]] = {}
            for page, target in zip(operation.source_pages, operation.target_pages):
                writers = self._reference_writers(page, target, operation.prompt_tokens)
                canonical[target] = {}
                sources[str(target)] = writers
                for region, writer in writers.items():
                    entries = [
                        (
                            rank,
                            receipt.get("source_digests", {})
                            .get(str(target), {})
                            .get(region),
                        )
                        for rank, receipt in enumerate(receipts)
                    ]
                    entries = [
                        (rank, digest) for rank, digest in entries if digest is not None
                    ]
                    if len(entries) != 1 or entries[0][0] != writer:
                        raise ValueError(
                            "prefix reference does not identify the actual source writer"
                        )
                    canonical[target][region] = entries[0][1]
            self._saved_digests.update(canonical)
            assert self._source is not None
            self._report(
                "admit",
                self._source,
                op_id,
                list(operation.source_pages),
                {str(p): digest for p, digest in canonical.items()},
                page_sources=sources,
            )
        operation.committed = True
        self._ready.update(operation.target_pages)

    def _admit_writer(self, page: int) -> int:
        assert self.prefix_layout is not None
        if self.admit_mode == "single_rank":
            return self.admit_rank
        return self.prefix_layout.groups[self.prefix_layout.decode(page)[0]][0]

    def _reference_writers(self, page: int, target: int, tokens: int) -> dict[str, int]:
        assert (
            self.prefix_layout is not None
            and self.page_writer is not None
            and self.index_writer is not None
        )
        owner = self._admit_writer(target)
        group = next(group for group in self.prefix_layout.groups if owner in group)
        main = next(
            rank
            for member, rank in enumerate(group)
            if page
            in PageWriter(
                member, len(group), self.page_size, self.page_writer.assignment
            ).pages(tokens)
        )
        index = next(
            member
            for member in range(self.index_writer.members)
            if page
            in PageWriter(member, self.index_writer.members, self.page_size).pages(
                tokens
            )
        )
        return dict(main=main, index=index)

    def _admit_digests(self, operation: _Admit) -> dict[str, dict[str, str]]:
        source = self._source
        if source is None or not source.verified:
            raise RuntimeError("prefix admit has no verified source")
        result = {}
        for page, target in zip(operation.source_pages, operation.target_pages):
            values = {
                key: value[page * self.page_size : (page + 1) * self.page_size]
                for key, value in source.values.items()
            }
            result[str(target)] = {
                region: self._page_digests(
                    {
                        target: {
                            key: value
                            for key, value in values.items()
                            if key[0] == region
                        }
                    }
                )[str(target)]
                for region, rank in self._reference_writers(
                    page, target, operation.prompt_tokens
                ).items()
                if rank == self.replica
            }
        return result

    def _tasks(
        self, pages: tuple[int, ...] | list[int]
    ) -> list[tuple[int | None, list[tuple[int, int]]]]:
        if self.prefix_layout is not None:
            return list(enumerate(self.prefix_layout.tasks(pages)))
        return [(None, list(enumerate(pages)))]

    def _rows(self, pages: list[int]) -> Tensor:
        offsets = torch.arange(self.page_size, dtype=torch.int64, device=self.device)
        values = torch.tensor(pages, dtype=torch.int64, device=self.device)
        return (values[:, None] * self.page_size + offsets).flatten()

    def admit(
        self,
        *,
        rid: str,
        op_id: int,
        slot: int,
        prompt_tokens: int,
        source_pages: list[int],
        target_pages: list[int],
    ) -> dict[str, Any] | None:
        """Submit once, then poll the same operation without releasing its source."""
        if self._fault is not None:
            raise RuntimeError(f"prefix store fault: {self._fault}")
        candidate = _Admit(
            rid=rid,
            op_id=op_id,
            slot=slot,
            prompt_tokens=prompt_tokens,
            source_pages=tuple(source_pages),
            target_pages=tuple(target_pages),
        )
        operation = self._operations.get(op_id)
        if operation is None:
            self._validate(candidate)
            self._operations[op_id] = operation = candidate
            self._free.difference_update(target_pages)
            try:
                if self.copy_executor is not None:
                    self._submit_pool_copy(operation)
                else:
                    self._submit(operation)
            except Exception as exc:
                self._fault = str(exc)
                raise
        elif any(
            getattr(operation, name) != getattr(candidate, name)
            for name in ("rid", "slot", "prompt_tokens", "source_pages", "target_pages")
        ):
            raise ValueError("conflicting duplicate prefix operation")
        if operation.receipt is None:
            if not self._copy_complete(operation):
                return None
            main, index = (
                self.manager.layout.prefix_main,
                self.manager.layout.prefix_index,
            )
            assert main is not None and index is not None
            if self.verify and self.prefix_layout is None:
                self._retain_reference(operation)
            operation.receipt = dict(
                readable=True,
                slot=slot,
                source_pages=source_pages.copy(),
                target_pages=target_pages.copy(),
                main_layers=main.layers,
                index_layers=index.layers,
            )
            if self.prefix_layout is not None:
                operation.receipt.update(
                    written_pages=operation.written_pages.copy(),
                    start_segment=self._request_segment,
                    main_bytes=len(operation.written_pages)
                    * self.page_size
                    * main.row_bytes
                    * main.layers,
                    index_bytes=len(operation.written_pages)
                    * self.page_size
                    * index.row_bytes
                    * index.layers,
                )
                if self.verify:
                    operation.receipt["source_digests"] = self._admit_digests(operation)
            operation.retained.clear()
            if self.observer is not None:
                self.observer.emit(
                    "copy_complete_observed",
                    rid=rid,
                    op_id=op_id,
                    kind="admit",
                    **operation.receipt,
                )
            if self.prefix_layout is None:
                operation.committed = True
                self._ready.update(target_pages)
        return copy.deepcopy(operation.receipt)

    def _copy_complete(self, operation: _Admit | _Read) -> bool:
        if self.copy_executor is None or (
            isinstance(operation, _Read) and operation.kind == "load_back"
        ):
            return bool(operation.event.query())
        result = self.copy_executor.poll(operation.op_id)
        if result.state == "PENDING":
            return False
        if result.state != "READY":
            self._fault = f"pool copy {result.state}: {result.error}"
            raise RuntimeError(self._fault)
        return True

    def _submit_pool_copy(self, operation: _Admit | _Read) -> None:
        """Resolve SDK page blocks on tick; the executor owns no prefix state."""
        assert self.copy_executor is not None
        admit = isinstance(operation, _Admit)
        pages = (
            operation.target_pages
            if isinstance(operation, _Admit)
            else operation.source_pages
        )
        blocks = []
        observed_blocks = []
        if isinstance(operation, _Admit):
            operation.written_pages = [
                p
                for p in pages
                if self.prefix_layout is None or self._admit_writer(p) == self.replica
            ]
        for region, writer in (
            ("main", self.page_writer),
            ("index", self.index_writer),
        ):
            owned = (
                set(writer.pages(self._prompt_tokens)) if writer is not None else None
            )
            counts = []
            read_pages = []
            for segment, assigned in self._tasks(pages):
                count = 0
                for position, local_page in assigned:
                    if isinstance(operation, _Admit):
                        if pages[position] not in operation.written_pages:
                            continue
                        alive_page = operation.source_pages[position]
                    else:
                        if owned is not None and position not in owned:
                            continue
                        alive_page = position
                    alive = self.manager.view(0, 0, region="alive_" + region)
                    prefix = self.manager.view(
                        0, 0, region="prefix_" + region, segment=segment
                    )
                    alive_block = alive.page_block(
                        alive.physical_page(operation.slot, alive_page)
                    )
                    prefix_block = prefix.page_block(local_page)
                    src, dst = (
                        (alive_block, prefix_block)
                        if admit
                        else (prefix_block, alive_block)
                    )
                    blocks.append(CopyBlock(src[0], dst[0], src[2]))
                    if self.observer is not None:
                        observed_blocks.append(
                            dict(
                                region=region,
                                segment=segment,
                                source_page=alive_page if admit else pages[position],
                                destination_page=pages[position]
                                if admit
                                else alive_page,
                                source_region="alive_" + region
                                if admit
                                else "prefix_" + region,
                                destination_region="prefix_" + region
                                if admit
                                else "alive_" + region,
                                source_host=self.observer.identity["host"],
                                source_numa=self.manager.session.prefix_nodes[segment]
                                if self.manager.session
                                and not admit
                                and segment is not None
                                else self.manager.numa_node,
                                src_gva=src[0],
                                dst_gva=dst[0],
                                nbytes=src[2],
                            )
                        )
                    count += self.page_size
                    read_pages.append(pages[position])
                counts.append(count)
            if isinstance(operation, _Read):
                operation.segment_rows[region] = counts
                operation.read_pages[region] = read_pages
                if writer is not None:
                    rows = torch.tensor(sum(counts), dtype=torch.int64)
                    if region == "main":
                        operation.main_rows = rows
                    else:
                        operation.index_rows = rows
        task = CopyTask(
            operation.rid, operation.op_id, "admit" if admit else "fill", tuple(blocks)
        )
        self.copy_executor.submit(task)
        if self.observer is not None:
            self.observer.emit(
                "copy_plan",
                rid=operation.rid,
                op_id=operation.op_id,
                kind=task.kind,
                blocks=observed_blocks,
                sources=list(pages),
            )

    def _read_context(self) -> Any:
        if torch.device(self.device).type == "cpu":
            return nullcontext()
        if self._read_stream is None:
            self._read_stream = torch.npu.Stream()
        self._read_stream.wait_stream(torch.npu.current_stream())
        return torch.npu.stream(self._read_stream)

    def fill(
        self, *, rid: str, op_id: int, slot: int, source_pages: list[int]
    ) -> dict[str, Any] | None:
        """Copy retained pages into this request's alive on an independent stream."""
        return self._read(_Read(rid, op_id, "fill", tuple(source_pages), slot))

    def load_back(
        self,
        *,
        rid: str,
        op_id: int,
        slot: int,
        source_pages: list[int],
        indices: Tensor,
        pool: Any,
    ) -> dict[str, Any] | None:
        """Restore both MLA parts and Index K at allocator-owned token indices."""
        return self._read(
            _Read(rid, op_id, "load_back", tuple(source_pages), slot, indices, pool)
        )

    def _read(self, candidate: _Read) -> dict[str, Any] | None:
        if self._fault is not None:
            raise RuntimeError(f"prefix store fault: {self._fault}")
        rid, op_id, slot, source_pages = (
            candidate.rid,
            candidate.op_id,
            candidate.slot,
            candidate.source_pages,
        )
        operation = self._reads.get(op_id)
        if operation is None:
            positive_int("op_id", op_id)
            check_index("target slot", slot, self.manager.layout.prompt.slots)
            if (
                not rid
                or not source_pages
                or len(set(source_pages)) != len(source_pages)
                or any(type(p) is not int or p not in self._ready for p in source_pages)
                or len(source_pages) * self.page_size
                > self.manager.layout.prompt.tokens
                or op_id in self._operations
            ):
                raise ValueError("prefix read requires unique ready source pages")
            self._reads[op_id] = operation = candidate
            if self.observer is not None:
                self.observer.emit(
                    "copy_submit", rid=rid, op_id=op_id, kind=operation.kind
                )
            try:
                if operation.kind == "fill" and self.copy_executor is not None:
                    self._submit_pool_copy(operation)
                else:
                    from .observation_device import device_range

                    with (
                        self._read_context(),
                        (
                            device_range(f"{operation.kind}:{op_id}")
                            if self.observer is not None
                            and torch.device(self.device).type == "npu"
                            else nullcontext()
                        ),
                    ):
                        if operation.kind == "fill":
                            self._submit_fill(operation)
                        else:
                            self._submit_load_back(operation)
            except Exception as exc:
                self._fault = str(exc)
                raise
        elif (
            any(
                getattr(operation, key) != getattr(candidate, key)
                for key in ("rid", "kind", "source_pages", "slot")
            )
            or operation.indices is not candidate.indices
            or operation.pool is not candidate.pool
        ):
            raise ValueError("conflicting duplicate prefix read")
        if operation.receipt is None:
            if not self._copy_complete(operation):
                return None
            main, index = (
                self.manager.layout.prefix_main,
                self.manager.layout.prefix_index,
            )
            assert main is not None and index is not None
            if self.verify:
                self._verify_read(operation)
            operation.receipt = dict(
                readable=True,
                slot=slot,
                source_pages=list(source_pages),
                tokens=len(source_pages) * self.page_size,
                main_layers=main.layers,
                index_layers=index.layers,
            )
            if operation.indices is not None:
                operation.receipt["prefix_indices"] = operation.indices.cpu().tolist()
            if operation.main_rows is not None:
                operation.receipt["main_rows"] = int(operation.main_rows.item())
            if operation.index_rows is not None:
                operation.receipt["index_rows"] = int(operation.index_rows.item())
            if self.prefix_layout is not None:
                operation.receipt["segment_rows"] = operation.segment_rows
                operation.receipt["read_pages"] = operation.read_pages
                operation.receipt["gather_width_pages"] = operation.gather_width
                for region, geometry in (("main", main), ("index", index)):
                    operation.receipt[region + "_bytes"] = (
                        sum(operation.segment_rows[region])
                        * geometry.row_bytes
                        * geometry.layers
                    )
            operation.retained.clear()
            if self.observer is not None:
                self.observer.emit(
                    "copy_complete_observed",
                    rid=rid,
                    op_id=op_id,
                    kind=operation.kind,
                    **operation.receipt,
                )
        return copy.deepcopy(operation.receipt)

    def _verify_read(self, operation: _Read) -> None:
        source = self._source
        if source is None or (source.rid, source.slot) != (
            operation.rid,
            operation.slot,
        ):
            raise RuntimeError("prefix read has no matching content reference")
        if self.prefix_layout is not None:
            self._verify_shared_read(operation, source)
            return
        references = {
            logical: self._saved[page]
            for logical, page in enumerate(operation.source_pages)
        }
        if operation.kind == "fill":
            # References come from A's original computed values, never B's destination.
            for logical, reference in references.items():
                for (region, layer), expected in reference.items():
                    self.capture_source(
                        region,
                        layer,
                        expected,
                        torch.full((self.page_size,), operation.slot),
                        torch.arange(
                            logical * self.page_size, (logical + 1) * self.page_size
                        ),
                        torch.ones(self.page_size, dtype=torch.bool),
                    )
            self._report(
                "fill",
                source,
                operation.op_id,
                list(operation.source_pages),
                self._page_digests(references),
            )
            return
        actual_pages = self._native_pages(operation)
        assert operation.indices is not None
        for logical, reference in references.items():
            for key, expected in reference.items():
                if not torch.equal(actual_pages[logical][key], expected):
                    raise RuntimeError(f"load_back native {key[0]} KV content mismatch")
        self._report(
            "load_back",
            source,
            operation.op_id,
            list(operation.source_pages),
            self._page_digests(actual_pages),
            prefix_indices=operation.indices.cpu().tolist(),
            parts=[operation.pool.kv_lora_rank, operation.pool.qk_rope_head_dim],
        )

    def _native_pages(
        self, operation: _Read
    ) -> dict[int, dict[tuple[str, int], Tensor]]:
        pool, indices = operation.pool, operation.indices
        assert indices is not None
        cpu_indices = indices.cpu()
        actual: dict[int, dict[tuple[str, int], Tensor]] = {
            p: {} for p in range(len(operation.source_pages))
        }
        for region, count in (
            ("main", pool.layer_num),
            ("index", len(pool.indexer_layer_ids)),
        ):
            for layer in range(count):
                if region == "main":
                    rows = []
                    for buffer, dim in (
                        (
                            pool.get_key_buffer(pool.start_layer + layer),
                            pool.kv_lora_rank,
                        ),
                        (
                            pool.get_value_buffer(pool.start_layer + layer),
                            pool.qk_rope_head_dim,
                        ),
                    ):
                        host = buffer.cpu()
                        if pool.use_fia_nz:
                            host = host.view(-1, dim // 16, self.page_size, 16).permute(
                                0, 2, 1, 3
                            )
                            rows.append(
                                host[
                                    cpu_indices // self.page_size,
                                    cpu_indices % self.page_size,
                                ].reshape(-1, 1, dim)
                            )
                        else:
                            rows.append(host.view(-1, 1, dim)[cpu_indices])
                    values = torch.cat(rows, dim=-1)
                else:
                    values = (
                        pool.get_index_k_buffer(pool.indexer_layer_ids[layer])
                        .cpu()
                        .reshape(-1, 1, pool.index_head_dim)
                        .index_select(0, cpu_indices)
                    )
                for page in actual:
                    actual[page][region, layer] = values[
                        page * self.page_size : (page + 1) * self.page_size
                    ]
        return actual

    def _verify_shared_read(self, operation: _Read, source: _Source) -> None:
        expected = {
            str(position): self._saved_digests[page]
            for position, page in enumerate(operation.source_pages)
        }
        if operation.kind == "load_back":
            actual = self._native_pages(operation)
            if self._region_digests(actual) != expected:
                raise RuntimeError(
                    "load_back native content mismatch with shared prefix source writers"
                )
            # Only independently verified HBM becomes this request's inherited source.
            for page, values in actual.items():
                for (region, layer), value in values.items():
                    self.capture_source(
                        region,
                        layer,
                        value,
                        torch.full((self.page_size,), operation.slot),
                        torch.arange(
                            page * self.page_size, (page + 1) * self.page_size
                        ),
                        torch.ones(self.page_size, dtype=torch.bool),
                    )
        elif (
            any(
                not bool(mask[: len(expected) * self.page_size].all())
                for mask in source.coverage.values()
            )
            or not source.coverage
        ):
            raise RuntimeError("fill reference requires verified native restore")
        self._report(
            operation.kind,
            source,
            operation.op_id,
            list(operation.source_pages),
            expected,
            **(
                dict(
                    prefix_indices=operation.indices.cpu().tolist(),
                    parts=[
                        operation.pool.kv_lora_rank,
                        operation.pool.qk_rope_head_dim,
                    ],
                )
                if operation.indices is not None
                else {}
            ),
        )

    def _submit_load_back(self, operation: _Read) -> None:
        indices, pool = operation.indices, operation.pool
        main, index = self.manager.layout.prefix_main, self.manager.layout.prefix_index
        assert main is not None and index is not None and indices is not None
        count = len(operation.source_pages) * self.page_size
        if (
            indices.ndim != 1
            or indices.dtype != torch.int64
            or indices.numel() != count
            or indices.device != torch.device(self.device)
            or pool.page_size != self.page_size
            or pool.layer_num != main.layers
            or pool.kv_lora_rank + pool.qk_rope_head_dim != main.dim
            or len(pool.indexer_layer_ids) != index.layers
            or pool.index_head_dim != index.dim
            or pool.index_k_scale_buffer is not None
        ):
            raise ValueError("native prefix geometry differs from saved pages")
        pages = indices.cpu().reshape(-1, self.page_size)
        if (
            bool((pages < self.page_size).any())
            or pages[:, 0].unique().numel() != pages.shape[0]
            or bool((pages[:, 0] % self.page_size != 0).any())
            or not torch.equal(
                pages - pages[:, :1], torch.arange(self.page_size).expand_as(pages)
            )
        ):
            raise ValueError("native prefix requires complete unique allocator pages")
        assignments = assign_prefix_pages(
            operation.source_pages,
            self.readers,
            self.read_assignment,
            self.prefix_layout,
        )
        rank = self.replica if self.readers > 1 else 0
        local_pages = assignments[rank]
        width = max(map(len, assignments))
        operation.gather_width = width
        operation.read_pages = {
            region: [operation.source_pages[p] for p in local_pages]
            for region in ("main", "index")
        }
        padded_count = width * self.page_size
        total_rows = self.readers * padded_count
        transfers = []
        tasks = self._tasks([operation.source_pages[p] for p in local_pages])
        for segment, assigned in tasks:
            if not assigned:
                continue
            source = self._rows([offset for _, offset in assigned])
            target = (
                self._rows([position for position, _ in assigned]) + rank * padded_count
            )
            valid = torch.ones_like(source, dtype=torch.bool)
            transfers.append((segment, source, target, valid))
            operation.retained.extend((source, target, valid))
        operation.segment_rows = {
            region: [len(assigned) * self.page_size for _, assigned in tasks]
            for region in ("main", "index")
        }
        slot_rows: list[int] = []
        native_rows: list[int] = []
        for reader, reader_pages in enumerate(assignments):
            for offset, page in enumerate(reader_pages):
                slot = reader * width + offset
                slot_rows.extend(
                    range(slot * self.page_size, (slot + 1) * self.page_size)
                )
                native_rows.extend(pages[page].tolist())
        # One table per restore, reused by both data types and every layer.
        table = torch.tensor(
            [slot_rows, native_rows], dtype=torch.int64, device=self.device
        )
        buffers = {
            region: torch.empty(
                (total_rows, 1, layout.dim), dtype=torch.bfloat16, device=self.device
            )
            for region, layout in (("main", main), ("index", index))
        }
        operation.retained.extend((indices, table, *buffers.values()))
        if self._scatter_kernel is None:
            from .restore_kernel import scatter_rows

            self._scatter_kernel = scatter_rows
        for region, layout in (("main", main), ("index", index)):
            gathered = buffers[region]
            local = gathered[rank * padded_count : (rank + 1) * padded_count]
            for layer in range(layout.layers):
                for segment, source, target, valid in transfers:
                    view = self.manager.view(
                        0, layer, region="prefix_" + region, segment=segment
                    )
                    copy_rows(
                        self._copy,
                        self._dtype,
                        gathered,
                        source,
                        target,
                        valid,
                        row_bytes=layout.row_bytes,
                        source_view=view,
                    )
                if self.readers > 1:
                    assert self.all_gather is not None
                    self.all_gather(gathered, local)
                if region == "main":
                    model_layer = pool.start_layer + layer
                    key, rope = (
                        pool.get_key_buffer(model_layer),
                        pool.get_value_buffer(model_layer),
                    )
                    key_dim, rope_dim = pool.kv_lora_rank, pool.qk_rope_head_dim
                    nz = pool.use_fia_nz
                else:
                    key, rope = (
                        pool.get_index_k_buffer(pool.indexer_layer_ids[layer]),
                        None,
                    )
                    key_dim, rope_dim, nz = pool.index_head_dim, 0, False
                for buffer, dim in ((key, key_dim), (rope, rope_dim)):
                    if buffer is not None and (
                        buffer.dtype != gathered.dtype
                        or int(pages.max()) >= buffer.numel() // dim
                    ):
                        raise ValueError(
                            "native prefix indices exceed the destination buffer"
                        )
                self._scatter_kernel(
                    gathered,
                    table,
                    key,
                    rope,
                    key_dim,
                    rope_dim,
                    self.page_size,
                    nz,
                )
        operation.event = self._event_factory()
        operation.event.record()

    def _submit_fill(self, operation: _Read) -> None:
        tasks = self._tasks(operation.source_pages)
        for region, writer in (
            ("main", self.page_writer),
            ("index", self.index_writer),
        ):
            owned = (
                set(writer.pages(self._prompt_tokens)) if writer is not None else None
            )
            operation.read_pages[region] = []
            counts = []
            for segment, assigned in tasks:
                selected = [
                    (position, offset)
                    for position, offset in assigned
                    if owned is None or position in owned
                ]
                counts.append(len(selected) * self.page_size)
                operation.read_pages[region].extend(
                    operation.source_pages[position] for position, _ in selected
                )
                if not selected:
                    continue
                source = self._rows([offset for _, offset in selected])
                target = self._rows([position for position, _ in selected])
                target += operation.slot * self.manager.view(0, 0).token_capacity
                valid = torch.ones_like(source, dtype=torch.bool)
                operation.retained.extend((source, target, valid))
                self._copy_region(
                    "prefix_" + region,
                    "alive_" + region,
                    source,
                    target,
                    valid,
                    source_segment=segment,
                )
            operation.segment_rows[region] = counts
            if writer is not None:
                rows = torch.tensor(sum(counts), dtype=torch.int64)
                if region == "main":
                    operation.main_rows = rows
                else:
                    operation.index_rows = rows
        operation.event = self._event_factory()
        operation.event.record()

    def _validate(self, operation: _Admit) -> None:
        positive_int("op_id", operation.op_id)
        check_index("source slot", operation.slot, self.manager.layout.prompt.slots)
        positive_int("prompt_tokens", operation.prompt_tokens)
        if (
            not operation.rid
            or operation.prompt_tokens % self.page_size
            or operation.prompt_tokens > self.manager.layout.prompt.tokens
        ):
            raise ValueError("invalid prefix source request")
        source, target = operation.source_pages, operation.target_pages
        if (
            not source
            or len(source) != len(target)
            or len(set(source)) != len(source)
            or len(set(target)) != len(target)
        ):
            raise ValueError("prefix requires unique paired source and target pages")
        for page in source:
            check_index("source page", page, operation.prompt_tokens // self.page_size)
        for page in target:
            if type(page) is not int or page not in self._free:
                raise ValueError("prefix target page is not free")

    def _copy(self, *args: Any) -> None:
        if self._kernel is None:
            importlib.import_module("sgl_kernel_npu.sparsity_driven_kv_offload")
            self._kernel = IndexedCopy()
        self._kernel(*args)

    def _copy_region(
        self,
        source_region: str,
        target_region: str,
        source: Tensor,
        target: Tensor,
        valid: Tensor,
        *,
        source_segment: int | None = None,
        target_segment: int | None = None,
    ) -> None:
        """Resolve this shard's mappings separately from page selection and submission."""
        _, layout = self.manager.layout.regions(0)[source_region]
        for layer in range(layout.layers):
            src = self.manager.view(
                0, layer, region=source_region, segment=source_segment
            )
            dst = self.manager.view(
                0, layer, region=target_region, segment=target_segment
            )
            copy_rows(
                self._copy,
                self._dtype,
                self._dtype,
                source,
                target,
                valid,
                row_bytes=src.layout.row_bytes,
                source_view=src,
                target_view=dst,
            )

    def _submit(self, operation: _Admit) -> None:
        offsets = torch.arange(self.page_size, dtype=torch.int64, device=self.device)
        tasks = self._tasks(operation.target_pages)
        operation.written_pages = [
            page
            for page in operation.target_pages
            if self.prefix_layout is None or self._admit_writer(page) == self.replica
        ]
        for segment, pages in tasks:
            if not pages or (
                self.prefix_layout is not None
                and self._admit_writer(operation.target_pages[pages[0][0]])
                != self.replica
            ):
                continue
            source = torch.tensor(
                [operation.source_pages[p] for p, _ in pages],
                dtype=torch.int64,
                device=self.device,
            )
            target = torch.tensor(
                [offset for _, offset in pages], dtype=torch.int64, device=self.device
            )
            source = (source[:, None] * self.page_size + offsets).flatten()
            source += operation.slot * self.manager.view(0, 0).token_capacity
            target = (target[:, None] * self.page_size + offsets).flatten()
            valid = torch.ones_like(source, dtype=torch.bool)
            operation.retained.extend((source, target, valid))
            for region in ("main", "index"):
                self._copy_region(
                    "alive_" + region,
                    "prefix_" + region,
                    source,
                    target,
                    valid,
                    target_segment=segment,
                )
        operation.event = self._event_factory()
        operation.event.record()

    def assert_source_releasable(self, rid: str) -> None:
        operations: tuple[_Admit | _Read, ...] = (
            *self._operations.values(),
            *self._reads.values(),
        )
        if self._fault is not None or any(
            operation.rid == rid
            and (
                operation.receipt is None
                or (isinstance(operation, _Admit) and not operation.committed)
            )
            for operation in operations
        ):
            raise RuntimeError("prefix source has pending or failed copies")

    def release_source(self, rid: str) -> None:
        """Discard per-request receipts after actual alive free, retaining prefix pages."""
        self.assert_source_releasable(rid)
        if self.verify:
            source = self._source
            if source is None or source.rid != rid:
                raise RuntimeError("prefix verification has no matching request")
            pages = (
                {str(p): value for p, value in self._saved_digests.items()}
                if self.prefix_layout is not None
                else self._page_digests(self._saved)
            )
            self._report("retained", source, 0, [], pages)
            self._source = None
        if self.copy_executor is not None:
            operations: tuple[_Admit | _Read, ...] = (
                *self._operations.values(),
                *self._reads.values(),
            )
            for operation in operations:
                if operation.rid == rid and (
                    isinstance(operation, _Admit) or operation.kind == "fill"
                ):
                    self.copy_executor.retire(operation.op_id)
        self._operations = {
            op_id: operation
            for op_id, operation in self._operations.items()
            if operation.rid != rid
        }
        self._reads = {
            op_id: operation
            for op_id, operation in self._reads.items()
            if operation.rid != rid
        }
        if self.observer is not None:
            self.observer.emit("source_release", rid=rid)
            self.observer.flush()

    def begin_request(self, rid: str, slot: int, tokens: int) -> None:
        if self.prefix_layout is not None and rid != self._request_rid:
            self._request_segment = (
                self._next_segment if self.start_segment is None else self.start_segment
            )
            self._next_segment = (self._next_segment + 1) % len(
                self.prefix_layout.groups
            )
            self._request_rid = rid
        self._prompt_tokens = tokens
        if self.verify:
            if self._source is not None:
                raise RuntimeError("prefix verification request was not released")
            self._source = _Source(rid=rid, slot=slot, tokens=tokens)

    def capture_source(
        self,
        region: str,
        layer: int,
        values: Tensor,
        slots: Tensor,
        positions: Tensor,
        valid: Tensor,
    ) -> None:
        """Record actual computed values, never a copy read from the target region."""
        if not self.verify:
            return
        source = self._source
        if source is None:
            raise RuntimeError("prefix verification has no allocated source")
        mask = valid.cpu()
        rows, positions = slots.cpu()[mask], positions.cpu()[mask]
        if not bool(torch.all(rows == source.slot)) or bool(
            torch.any((positions < 0) | (positions >= source.tokens))
        ):
            raise RuntimeError("prefix reference differs from allocated source")
        key = region, layer
        if key not in source.values:
            source.values[key] = torch.empty(
                (source.tokens, *values.shape[1:]), dtype=values.dtype, device="cpu"
            )
            source.coverage[key] = torch.zeros(source.tokens, dtype=torch.bool)
        source.values[key][positions] = values.detach().cpu()[mask]
        source.coverage[key][positions] = True

    @staticmethod
    def _page_digests(
        pages: dict[int, dict[tuple[str, int], Tensor]],
    ) -> dict[str, str]:
        digests = {}
        for page, reference in sorted(pages.items()):
            digest = hashlib.sha256()
            for _, values in sorted(reference.items()):
                digest.update(values.contiguous().view(torch.uint8).numpy().tobytes())
            digests[str(page)] = digest.hexdigest()
        return digests

    @classmethod
    def _region_digests(
        cls, pages: dict[int, dict[tuple[str, int], Tensor]]
    ) -> dict[str, dict[str, str]]:
        return {
            str(page): {
                region: cls._page_digests(
                    {
                        page: {
                            key: value
                            for key, value in values.items()
                            if key[0] == region
                        }
                    }
                )[str(page)]
                for region in ("main", "index")
            }
            for page, values in pages.items()
        }

    def verify_source(self, slot: int, tokens: int, *, start: int = 0) -> None:
        """Verify captured source coverage; never read back alive or prefix DRAM."""
        if not self.verify:
            return
        source = self._source
        if source is None or source.slot != slot:
            raise RuntimeError("prefix verification has no matching source slot")
        end = start + tokens
        if end != source.tokens or source.verified:
            return
        main, index = self.manager.layout.prefix_main, self.manager.layout.prefix_index
        assert main is not None and index is not None
        required = {
            (region, layer)
            for region, count in (("main", main.layers), ("index", index.layers))
            for layer in range(count)
        }
        if set(source.values) != required or any(
            not bool(mask[start:end].all()) for mask in source.coverage.values()
        ):
            raise RuntimeError("prefix reference is missing source layers/tokens")
        pages = {
            page: {
                key: values[page * self.page_size : (page + 1) * self.page_size]
                for key, values in source.values.items()
            }
            for page in range(start // self.page_size, end // self.page_size)
        }
        source.verified = start == 0
        self._report(
            "suffix" if start else "alive",
            source,
            0,
            list(range(start // self.page_size, end // self.page_size)),
            self._region_digests(pages)
            if self.prefix_layout is not None
            else self._page_digests(pages),
        )

    def _retain_reference(self, operation: _Admit) -> None:
        source = self._source
        if (
            source is None
            or not source.verified
            or (source.rid, source.slot, source.tokens)
            != (operation.rid, operation.slot, operation.prompt_tokens)
        ):
            raise RuntimeError("prefix admit has no verified source")
        references = {
            target: {
                key: values[page * self.page_size : (page + 1) * self.page_size].clone()
                for key, values in source.values.items()
            }
            for page, target in zip(operation.source_pages, operation.target_pages)
        }
        pages = self._page_digests(references)
        self._saved.update(references)
        self._report(
            "admit", source, operation.op_id, list(operation.source_pages), pages
        )

    def _report(
        self,
        stage: str,
        source: _Source,
        op_id: int,
        source_pages: list[int],
        pages: dict[str, Any],
        **evidence: Any,
    ) -> None:
        main, index = self.manager.layout.prefix_main, self.manager.layout.prefix_index
        assert main is not None and index is not None
        log_prefix_content(
            dict(
                stage=stage,
                rank=self.replica,
                rid=source.rid,
                slot=source.slot,
                op_id=op_id,
                prompt_tokens=source.tokens,
                source_pages=source_pages,
                main_layers=main.layers,
                index_layers=index.layers,
                page_size=self.page_size,
                pages=pages,
                content_source=(
                    "native_hbm" if stage == "load_back" else "computed_source"
                ),
                bm_readback=False,
                prefix_shared=self.prefix_layout is not None,
                **evidence,
            ),
        )
